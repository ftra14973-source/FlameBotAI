package com.flamemc.flamebot;

import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import net.citizensnpcs.trait.SkinTrait;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

/**
 * Citizens-backed player NPC adapter.
 * No ArmorStand fallback is used.
 */
public final class NPCAdapter {

    private NPCAdapter() {
    }

    public static NPC create(Bot bot, Location location) {
        if (bot == null || location == null || !CitizensAPI.hasImplementation()) {
            return null;
        }

        NPC npc = CitizensAPI.getNPCRegistry().createNPC(
                EntityType.PLAYER,
                bot.getName()
        );

        npc.setProtected(false);
        npc.setUseMinecraftAI(false);
        npc.data().set(NPC.Metadata.REMOVE_FROM_PLAYERLIST, false);
        npc.data().set(NPC.Metadata.REMOVE_FROM_TABLIST, false);
        npc.data().set(NPC.Metadata.NAMEPLATE_VISIBLE, true);
        npc.data().set(NPC.Metadata.COLLIDABLE, true);
        npc.data().set(NPC.Metadata.DAMAGE_OTHERS, true);
        npc.data().set(NPC.Metadata.PICKUP_ITEMS, true);
        npc.data().set(NPC.Metadata.TRACKING_RANGE, 64);

        SkinTrait skin = npc.getOrAddTrait(SkinTrait.class);
        skin.setSkinName(bot.getName(), true);
        skin.setFetchDefaultSkin(true);

        if (!npc.spawn(location)) {
            CitizensAPI.getNPCRegistry().deregister(npc);
            return null;
        }

        return npc;
    }

    public static Entity getEntity(NPC npc) {
        return npc == null ? null : npc.getEntity();
    }

    public static Player getPlayer(NPC npc) {
        Entity entity = getEntity(npc);
        return entity instanceof Player player ? player : null;
    }
}
