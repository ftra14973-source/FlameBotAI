package com.flamemc.flamebot;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

/** Item factory/helper. */
public final class ItemManager {
    public ItemStack create(Material material,int amount){return material==null?null:new ItemStack(material,Math.max(1,amount));}
    public boolean isUseful(ItemStack item){return item!=null&&!item.getType().isAir();}
    public boolean isBamboo(ItemStack item){return item!=null&&item.getType()==Material.BAMBOO;}
}
