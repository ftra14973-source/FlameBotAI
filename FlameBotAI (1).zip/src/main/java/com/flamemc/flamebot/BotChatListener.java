package com.flamemc.flamebot;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
public final class BotChatListener implements Listener {
 private final FlameBotAI plugin;
 public BotChatListener(FlameBotAI plugin){this.plugin=plugin;}
 @EventHandler public void onChat(AsyncPlayerChatEvent e){if(plugin.getChatManager()!=null){} }
}
