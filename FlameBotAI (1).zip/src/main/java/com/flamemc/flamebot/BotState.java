package com.flamemc.flamebot;

/**
 * Represents the current activity/state of an AI bot.
 */
public enum BotState {

    /**
     * Bot has no important task.
     */
    IDLE,

    /**
     * Bot is leaving its current area and exploring.
     */
    EXPLORING,

    /**
     * Bot is travelling to another location.
     */
    TRAVELLING,

    /**
     * Bot is searching for resources.
     */
    SEARCHING_RESOURCE,

    /**
     * Bot is mining.
     */
    MINING,

    /**
     * Bot is farming crops.
     */
    FARMING,

    /**
     * Bot is specifically working on bamboo.
     */
    BAMBOO_FARMING,

    /**
     * Bot is fighting a player.
     */
    PVP_COMBAT,

    /**
     * Bot is fighting mobs.
     */
    MOB_COMBAT,

    /**
     * Bot is avoiding danger.
     */
    ESCAPING,

    /**
     * Bot is collecting dropped items.
     */
    COLLECTING_LOOT,

    /**
     * Bot is managing its inventory.
     */
    MANAGING_INVENTORY,

    /**
     * Bot is returning to its base.
     */
    RETURNING_HOME,

    /**
     * Bot is inside or working around its base.
     */
    AT_BASE,

    /**
     * Bot is building a structure.
     */
    BUILDING,

    /**
     * Bot is repairing a structure.
     */
    REPAIRING,

    /**
     * Bot is storing items.
     */
    STORING_ITEMS,

    /**
     * Bot is selling items through /sellgui.
     */
    SELLING,

    /**
     * Bot is checking its balance/economy.
     */
    CHECKING_BALANCE,

    /**
     * Bot is using a server command.
     */
    USING_COMMAND,

    /**
     * Bot is talking with a player.
     */
    TALKING,

    /**
     * Bot is talking with another bot.
     */
    BOT_CONVERSATION,

    /**
     * Bot is following a player.
     */
    FOLLOWING_PLAYER,

    /**
     * Bot is following another bot.
     */
    FOLLOWING_BOT,

    /**
     * Bot is defending a teammate/base.
     */
    DEFENDING,

    /**
     * Bot is waiting for a decision.
     */
    THINKING,

    /**
     * Bot is temporarily inactive.
     */
    AFK,

    /**
     * Bot has died and is waiting to respawn.
     */
    DEAD,

    /**
     * Bot is respawning.
     */
    RESPAWNING,

    /**
     * Special state used by UNKNOWN.
     */
    OBSERVING,

    /**
     * Bot is performing an unknown/mysterious activity.
     */
    MYSTERIOUS_ACTIVITY;

    /**
     * Returns a readable name for the current state.
     */
    public String getDisplayName() {

        return switch (this) {

            case IDLE -> "Idle";
            case EXPLORING -> "Exploring";
            case TRAVELLING -> "Travelling";
            case SEARCHING_RESOURCE -> "Searching Resource";
            case MINING -> "Mining";
            case FARMING -> "Farming";
            case BAMBOO_FARMING -> "Bamboo Farming";
            case PVP_COMBAT -> "PvP Combat";
            case MOB_COMBAT -> "Mob Combat";
            case ESCAPING -> "Escaping";
            case COLLECTING_LOOT -> "Collecting Loot";
            case MANAGING_INVENTORY -> "Managing Inventory";
            case RETURNING_HOME -> "Returning Home";
            case AT_BASE -> "At Base";
            case BUILDING -> "Building";
            case REPAIRING -> "Repairing";
            case STORING_ITEMS -> "Storing Items";
            case SELLING -> "Selling";
            case CHECKING_BALANCE -> "Checking Balance";
            case USING_COMMAND -> "Using Command";
            case TALKING -> "Talking";
            case BOT_CONVERSATION -> "Bot Conversation";
            case FOLLOWING_PLAYER -> "Following Player";
            case FOLLOWING_BOT -> "Following Bot";
            case DEFENDING -> "Defending";
            case THINKING -> "Thinking";
            case AFK -> "AFK";
            case DEAD -> "Dead";
            case RESPAWNING -> "Respawning";
            case OBSERVING -> "Observing";
            case MYSTERIOUS_ACTIVITY -> "Mysterious Activity";

        };
    }

    /**
     * Converts text into a BotState.
     * Invalid values return IDLE.
     */
    public static BotState fromString(String value) {

        if (value == null || value.isBlank()) {
            return IDLE;
        }

        try {

            return BotState.valueOf(
                    value.trim().toUpperCase()
            );

        } catch (IllegalArgumentException exception) {

            return IDLE;
        }
    }

    /**
     * Checks if the bot is currently fighting.
     */
    public boolean isCombat() {
        return this == PVP_COMBAT || this == MOB_COMBAT;
    }

    /**
     * Checks if the bot is doing resource work.
     */
    public boolean isWorking() {

        return this == MINING
                || this == FARMING
                || this == BAMBOO_FARMING
                || this == BUILDING
                || this == REPAIRING;
    }

    /**
     * Checks if the bot is travelling.
     */
    public boolean isTravelling() {

        return this == EXPLORING
                || this == TRAVELLING
                || this == RETURNING_HOME
                || this == FOLLOWING_PLAYER
                || this == FOLLOWING_BOT;
    }

    /**
     * Checks if the bot is currently interacting with someone.
     */
    public boolean isSocial() {

        return this == TALKING
                || this == BOT_CONVERSATION
                || this == FOLLOWING_PLAYER;
    }

    /**
     * Checks if the bot is temporarily inactive.
     */
    public boolean isInactive() {

        return this == AFK
                || this == DEAD
                || this == RESPAWNING;
    }
}