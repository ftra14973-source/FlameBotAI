package com.flamemc.flamebot;
import java.util.concurrent.ThreadLocalRandom;
public final class RandomUtil {
 private RandomUtil(){}
 public static int nextInt(int min,int max){return ThreadLocalRandom.current().nextInt(min,max+1);}
 public static double nextDouble(double min,double max){return ThreadLocalRandom.current().nextDouble(min,max);}
 public static boolean chance(double percent){return ThreadLocalRandom.current().nextDouble(100)<percent;}
 public static <T>T pick(T[] a){return a==null||a.length==0?null:a[ThreadLocalRandom.current().nextInt(a.length)];}
}
