package com.flamemc.flamebot;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
public final class BotDamageListener implements Listener {
 private final FlameBotAI plugin;
 public BotDamageListener(FlameBotAI plugin){this.plugin=plugin;}
 @EventHandler public void onDamage(EntityDamageEvent e){Bot bot=plugin.getBotManager()==null?null:plugin.getBotManager().getBotByEntity(e.getEntity());if(bot==null)return;if(e.getFinalDamage()>=bot.getHealth())bot.setAlive(false);else bot.setHealth(bot.getHealth()-(int)Math.ceil(e.getFinalDamage()));bot.markAction();if(e.getEntity() instanceof LivingEntity l)bot.setHealth((int)Math.round(Math.max(0,l.getHealth())));}
}
