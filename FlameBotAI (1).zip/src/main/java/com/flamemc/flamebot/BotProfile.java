package com.flamemc.flamebot;

import org.bukkit.Location;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Stores the complete profile and persistent preferences of an AI bot.
 */
public class BotProfile {

    private final String name;
    private BotRole role;

    private int intelligence;
    private int aggression;
    private int friendliness;
    private int bravery;
    private int curiosity;
    private int workPriority;
    private int socialLevel;

    private boolean enabled;
    private boolean canChat;
    private boolean canBuild;
    private boolean canFight;
    private boolean canFarm;
    private boolean canMine;
    private boolean canTrade;
    private boolean canUseCommands;

    private String personality;
    private String currentObjective;

    private Location homeLocation;
    private Location baseLocation;
    private Location lastLocation;

    private final Map<String, Object> memory = new HashMap<>();

    /**
     * Creates a bot profile with default AI values.
     */
    public BotProfile(String name, BotRole role) {

        this.name = name;
        this.role = role;

        this.intelligence = 70;
        this.aggression = 50;
        this.friendliness = 50;
        this.bravery = 70;
        this.curiosity = 70;
        this.workPriority = 60;
        this.socialLevel = 50;

        this.enabled = true;
        this.canChat = true;
        this.canBuild = true;
        this.canFight = true;
        this.canFarm = true;
        this.canMine = true;
        this.canTrade = true;
        this.canUseCommands = true;

        this.personality = "balanced";
        this.currentObjective = "explore";
    }

    /**
     * Creates a profile with custom personality values.
     */
    public BotProfile(
            String name,
            BotRole role,
            int intelligence,
            int aggression,
            int friendliness,
            int bravery,
            int curiosity,
            int workPriority,
            int socialLevel
    ) {

        this(name, role);

        this.intelligence = clamp(intelligence);
        this.aggression = clamp(aggression);
        this.friendliness = clamp(friendliness);
        this.bravery = clamp(bravery);
        this.curiosity = clamp(curiosity);
        this.workPriority = clamp(workPriority);
        this.socialLevel = clamp(socialLevel);
    }

    private int clamp(int value) {
        return Math.max(0, Math.min(100, value));
    }

    // =========================================================
    // BASIC INFORMATION
    // =========================================================

    public String getName() {
        return name;
    }

    public BotRole getRole() {
        return role;
    }

    public void setRole(BotRole role) {

        if (role != null) {
            this.role = role;
        }
    }

    // =========================================================
    // AI STATS
    // =========================================================

    public int getIntelligence() {
        return intelligence;
    }

    public void setIntelligence(int intelligence) {
        this.intelligence = clamp(intelligence);
    }

    public int getAggression() {
        return aggression;
    }

    public void setAggression(int aggression) {
        this.aggression = clamp(aggression);
    }

    public int getFriendliness() {
        return friendliness;
    }

    public void setFriendliness(int friendliness) {
        this.friendliness = clamp(friendliness);
    }

    public int getBravery() {
        return bravery;
    }

    public void setBravery(int bravery) {
        this.bravery = clamp(bravery);
    }

    public int getCuriosity() {
        return curiosity;
    }

    public void setCuriosity(int curiosity) {
        this.curiosity = clamp(curiosity);
    }

    public int getWorkPriority() {
        return workPriority;
    }

    public void setWorkPriority(int workPriority) {
        this.workPriority = clamp(workPriority);
    }

    public int getSocialLevel() {
        return socialLevel;
    }

    public void setSocialLevel(int socialLevel) {
        this.socialLevel = clamp(socialLevel);
    }

    // =========================================================
    // PERMISSIONS / CAPABILITIES
    // =========================================================

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean canChat() {
        return canChat;
    }

    public void setCanChat(boolean canChat) {
        this.canChat = canChat;
    }

    public boolean canBuild() {
        return canBuild;
    }

    public void setCanBuild(boolean canBuild) {
        this.canBuild = canBuild;
    }

    public boolean canFight() {
        return canFight;
    }

    public void setCanFight(boolean canFight) {
        this.canFight = canFight;
    }

    public boolean canFarm() {
        return canFarm;
    }

    public void setCanFarm(boolean canFarm) {
        this.canFarm = canFarm;
    }

    public boolean canMine() {
        return canMine;
    }

    public void setCanMine(boolean canMine) {
        this.canMine = canMine;
    }

    public boolean canTrade() {
        return canTrade;
    }

    public void setCanTrade(boolean canTrade) {
        this.canTrade = canTrade;
    }

    public boolean canUseCommands() {
        return canUseCommands;
    }

    public void setCanUseCommands(boolean canUseCommands) {
        this.canUseCommands = canUseCommands;
    }

    // =========================================================
    // PERSONALITY
    // =========================================================

    public String getPersonality() {
        return personality;
    }

    public void setPersonality(String personality) {

        if (personality != null && !personality.isBlank()) {
            this.personality = personality;
        }
    }

    public String getCurrentObjective() {
        return currentObjective;
    }

    public void setCurrentObjective(String currentObjective) {

        if (currentObjective != null && !currentObjective.isBlank()) {
            this.currentObjective = currentObjective;
        }
    }

    // =========================================================
    // LOCATIONS
    // =========================================================

    public Location getHomeLocation() {
        return cloneLocation(homeLocation);
    }

    public void setHomeLocation(Location homeLocation) {
        this.homeLocation = cloneLocation(homeLocation);
    }

    public Location getBaseLocation() {
        return cloneLocation(baseLocation);
    }

    public void setBaseLocation(Location baseLocation) {
        this.baseLocation = cloneLocation(baseLocation);
    }

    public Location getLastLocation() {
        return cloneLocation(lastLocation);
    }

    public void setLastLocation(Location lastLocation) {
        this.lastLocation = cloneLocation(lastLocation);
    }

    private Location cloneLocation(Location location) {

        return location == null ? null : location.clone();
    }

    // =========================================================
    // MEMORY
    // =========================================================

    /**
     * Stores arbitrary AI memory.
     */
    public void remember(String key, Object value) {

        if (key == null || key.isBlank()) {
            return;
        }

        if (value == null) {
            memory.remove(key);
            return;
        }

        memory.put(key, value);
    }

    /**
     * Returns a remembered value.
     */
    public Object recall(String key) {

        if (key == null) {
            return null;
        }

        return memory.get(key);
    }

    /**
     * Checks whether the bot remembers something.
     */
    public boolean remembers(String key) {

        return key != null && memory.containsKey(key);
    }

    /**
     * Removes one memory entry.
     */
    public void forget(String key) {

        if (key != null) {
            memory.remove(key);
        }
    }

    /**
     * Clears all temporary memory.
     */
    public void clearMemory() {
        memory.clear();
    }

    /**
     * Returns a read-only view of the bot's memory.
     */
    public Map<String, Object> getMemory() {

        return Collections.unmodifiableMap(memory);
    }

    // =========================================================
    // ROLE HELPERS
    // =========================================================

    public boolean isPvPBot() {
        return role == BotRole.PVP;
    }

    public boolean isGrinderBot() {
        return role == BotRole.GRINDER;
    }

    public boolean isMoneyBot() {
        return role == BotRole.MONEY;
    }

    public boolean isMysteriousBot() {
        return role == BotRole.MYSTERIOUS;
    }

    /**
     * Money bots should use /sellgui and never /sell.
     */
    public boolean shouldUseSellGui() {
        return role == BotRole.MONEY;
    }

    /**
     * Returns whether this bot is allowed to perform
     * normal survival activities.
     */
    public boolean canPerformSurvivalActions() {

        return enabled
                && (canMine || canFarm || canBuild || canFight);
    }

    // =========================================================
    // DEBUG / INFORMATION
    // =========================================================

    /**
     * Returns a short description useful for debugging.
     */
    public String getSummary() {

        return "BotProfile{" +
                "name='" + name + '\'' +
                ", role=" + role +
                ", intelligence=" + intelligence +
                ", aggression=" + aggression +
                ", friendliness=" + friendliness +
                ", bravery=" + bravery +
                ", curiosity=" + curiosity +
                ", workPriority=" + workPriority +
                ", socialLevel=" + socialLevel +
                ", enabled=" + enabled +
                ", personality='" + personality + '\'' +
                ", objective='" + currentObjective + '\'' +
                '}';
    }

    @Override
    public String toString() {
        return getSummary();
    }
}