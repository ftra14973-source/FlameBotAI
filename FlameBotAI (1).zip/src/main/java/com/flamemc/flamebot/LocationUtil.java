package com.flamemc.flamebot;
import org.bukkit.Location;
import org.bukkit.World;
public final class LocationUtil {
 private LocationUtil(){}
 public static boolean valid(Location l){return l!=null&&l.getWorld()!=null;}
 public static Location safe(Location l){if(!valid(l))return null;World w=l.getWorld();int y=w.getHighestBlockYAt(l.getBlockX(),l.getBlockZ())+1;return new Location(w,l.getBlockX()+.5,y,l.getBlockZ()+.5,l.getYaw(),l.getPitch());}
 public static double distance(Location a,Location b){return valid(a)&&valid(b)&&a.getWorld().equals(b.getWorld())?a.distance(b):Double.MAX_VALUE;}
 public static String key(Location l){return valid(l)?l.getWorld().getName()+":"+l.getBlockX()+":"+l.getBlockY()+":"+l.getBlockZ():"";}
}
