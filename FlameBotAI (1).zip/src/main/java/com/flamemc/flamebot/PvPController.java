package com.flamemc.flamebot;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** PvP behaviour for player-type Citizens NPCs. */
public final class PvPController {
    private final FlameBotAI plugin;
    private final CombatManager combat;
    private final TargetSelector selector;

    public PvPController(FlameBotAI plugin) {
        this.plugin = plugin;
        this.combat = new CombatManager(plugin, plugin.getBotManager());
        this.selector = new TargetSelector(plugin.getBotManager(), combat);
    }

    public void tick(Bot bot) {
        if (bot == null || !bot.isPvPBot() || !bot.isSpawned()) return;
        Entity target = selector.select(bot);
        if (target == null) { bot.setCurrentTask("Patrolling"); return; }
        combat.startCombat(bot, target);
        if (target instanceof LivingEntity living && combat.isInAttackRange(bot, living)) {
            combat.attack(bot, living);
        } else if (target.getLocation() != null) {
            bot.setCurrentTask("Chasing " + target.getName());
            if (plugin.getNPCManager() != null) plugin.getNPCManager().move(bot, target.getLocation());
        }
    }

    public Entity findTarget(Bot bot) { return selector.select(bot); }
    public boolean attack(Bot bot, LivingEntity target) { return combat.attack(bot, target); }
    public Location escape(Bot bot) { return combat.findEscapeLocation(bot); }
    public CombatManager getCombatManager() { return combat; }
}
