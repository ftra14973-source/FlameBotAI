package com.flamemc.flamebot;

import org.bukkit.Location;
import org.bukkit.Material;

/** Creates a small functional starter base for a bot. */
public final class BaseBuilder {
    private final FlameBotAI plugin;
    public BaseBuilder(FlameBotAI plugin){this.plugin=plugin;}
    public void buildStarterBase(Bot bot, Location origin){if(bot==null||origin==null)return; int r=3; for(int x=-r;x<=r;x++)for(int z=-r;z<=r;z++){origin.getWorld().getBlockAt(origin.getBlockX()+x,origin.getBlockY(),origin.getBlockZ()+z).setType(Material.OAK_PLANKS,false);} for(int x=-r;x<=r;x++)for(int y=1;y<=3;y++){origin.getWorld().getBlockAt(origin.getBlockX()+x,origin.getBlockY()+y,origin.getBlockZ()-r).setType(Material.OAK_PLANKS,false);origin.getWorld().getBlockAt(origin.getBlockX()+x,origin.getBlockY()+y,origin.getBlockZ()+r).setType(Material.OAK_PLANKS,false);} for(int z=-r;z<=r;z++)for(int y=1;y<=3;y++){origin.getWorld().getBlockAt(origin.getBlockX()-r,origin.getBlockY()+y,origin.getBlockZ()+z).setType(Material.OAK_PLANKS,false);origin.getWorld().getBlockAt(origin.getBlockX()+r,origin.getBlockY()+y,origin.getBlockZ()+z).setType(Material.OAK_PLANKS,false);} bot.setBaseLocation(origin);bot.remember("base_built",true);bot.setState(BotState.BUILDING);}
    public FlameBotAI getPlugin(){return plugin;}
}
