package com.flamemc.flamebot;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/** Safe command policy for bot actions. */
public final class CommandExecutor {
    private static final String[] ALLOWED={"spawn","rtp","home","tpa","msg","shop","sellgui","bal","pay","team","ah"};
    private static final String[] BLOCKED={"sell","op","deop","stop","restart","reload","plugins","pl","ban","kick","whitelist","give","summon","gamemode","tp"};
    private final FlameBotAI plugin;
    public CommandExecutor(FlameBotAI plugin){this.plugin=plugin;}
    public boolean isAllowed(String command){String c=command==null?"":command.trim().toLowerCase();if(c.startsWith("/"))c=c.substring(1);String root=c.split("\\s+",2)[0];for(String b:BLOCKED)if(root.equals(b))return false;for(String a:ALLOWED)if(root.equals(a))return true;return false;}
    public boolean execute(Bot bot,String command){if(bot==null||!isAllowed(command)||!(bot.getEntity() instanceof Player p))return false;String c=command.startsWith("/")?command.substring(1):command;if(c.toLowerCase().startsWith("sell ")||c.equalsIgnoreCase("sell"))return false;bot.setLastCommand("/"+c);bot.markCommand();return p.performCommand(c);}
    public FlameBotAI getPlugin(){return plugin;}
}
