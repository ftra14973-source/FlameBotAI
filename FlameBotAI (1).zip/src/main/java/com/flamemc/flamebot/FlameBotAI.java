package com.flamemc.flamebot;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public final class FlameBotAI extends JavaPlugin {

    private static FlameBotAI instance;

    private BotManager botManager;
    private AIController aiController;
    private ChatManager chatManager;
    private BotCommandManager botCommandManager;
    private NPCManager npcManager;

    @Override
    public void onEnable() {

        instance = this;

        getLogger().info("======================================");
        getLogger().info("        FlameBotAI is starting...");
        getLogger().info("        FlameMC AI Bot System");
        getLogger().info("======================================");

        // Create plugin data folder
        if (!getDataFolder().exists()) {
            if (getDataFolder().mkdirs()) {
                getLogger().info("Created FlameBotAI data folder.");
            }
        }

        // Create default configuration files
        saveDefaultConfig();

        saveResourceIfMissing("bots.yml");
        saveResourceIfMissing("chat.yml");
        saveResourceIfMissing("commands.yml");
        saveResourceIfMissing("personalities.yml");
        saveResourceIfMissing("structures.yml");

        // Initialize managers
        initializeManagers();

        // Register listeners
        registerListeners();

        // Start AI systems
        startSystems();

        getLogger().info("--------------------------------------");
        getLogger().info("FlameBotAI enabled successfully!");
        getLogger().info("AI System: ENABLED");
        getLogger().info("Bot System: ENABLED");
        getLogger().info("Chat System: ENABLED");
        getLogger().info("Command System: ENABLED");
        getLogger().info("======================================");
    }

    @Override
    public void onDisable() {

        getLogger().info("======================================");
        getLogger().info("       FlameBotAI is shutting down");
        getLogger().info("======================================");

        // Stop AI systems first
        if (aiController != null) {
            try {
                aiController.shutdown();
            } catch (Exception exception) {
                getLogger().warning(
                        "Could not shutdown AIController: "
                                + exception.getMessage()
                );
            }
        }

        // Remove/despawn bots
        if (botManager != null) {
            try {
                botManager.shutdown();
            } catch (Exception exception) {
                getLogger().warning(
                        "Could not shutdown BotManager: "
                                + exception.getMessage()
                );
            }
        }

        if (npcManager != null) {
            try {
                npcManager.shutdown();
            } catch (Exception exception) {
                getLogger().warning(
                        "Could not shutdown NPCManager: "
                                + exception.getMessage()
                );
            }
        }

        instance = null;

        getLogger().info("FlameBotAI disabled.");
    }

    /**
     * Initialize all major plugin managers.
     */
    private void initializeManagers() {

        getLogger().info("Initializing managers...");

        /*
         * Manager initialization order is important.
         *
         * BotManager controls bots.
         * NPCManager handles player-like NPC presentation.
         * AIController controls decision making.
         * ChatManager handles conversations.
         * BotCommandManager handles bot commands.
         */

        try {

            botManager = new BotManager(this);
            getLogger().info("BotManager initialized.");

        } catch (Exception exception) {

            getLogger().severe(
                    "Failed to initialize BotManager: "
                            + exception.getMessage()
            );

            botManager = null;
        }

        try {

            npcManager = new NPCManager(this);
            getLogger().info("NPCManager initialized.");

        } catch (Exception exception) {

            getLogger().severe(
                    "Failed to initialize NPCManager: "
                            + exception.getMessage()
            );

            npcManager = null;
        }

        try {

            chatManager = new ChatManager(this);
            getLogger().info("ChatManager initialized.");

        } catch (Exception exception) {

            getLogger().severe(
                    "Failed to initialize ChatManager: "
                            + exception.getMessage()
            );

            chatManager = null;
        }

        try {

            botCommandManager = new BotCommandManager(this);
            getLogger().info("BotCommandManager initialized.");

        } catch (Exception exception) {

            getLogger().severe(
                    "Failed to initialize BotCommandManager: "
                            + exception.getMessage()
            );

            botCommandManager = null;
        }

        try {

            aiController = new AIController(this);
            getLogger().info("AIController initialized.");

        } catch (Exception exception) {

            getLogger().severe(
                    "Failed to initialize AIController: "
                            + exception.getMessage()
            );

            aiController = null;
        }
    }

    /**
     * Register Bukkit event listeners.
     */
    private void registerListeners() {

        getLogger().info("Registering listeners...");

        try {

            if (getServer().getPluginManager()
                    .isPluginEnabled("FlameBotAI")) {

                if (botManager != null) {
                    getServer().getPluginManager().registerEvents(
                            new BotDamageListener(this),
                            this
                    );
                }

                if (chatManager != null) {
                    getServer().getPluginManager().registerEvents(
                            new BotChatListener(this),
                            this
                    );
                }

                getServer().getPluginManager().registerEvents(
                        new PlayerInteractionListener(this),
                        this
                );

                getLogger().info("Listeners registered.");

            }

        } catch (Exception exception) {

            getLogger().warning(
                    "Listener registration problem: "
                            + exception.getMessage()
            );
        }
    }

    /**
     * Start the AI and bot systems.
     */
    private void startSystems() {

        getLogger().info("Starting FlameBotAI systems...");

        // Start bot manager
        if (botManager != null) {

            try {

                botManager.start();

                getLogger().info("BotManager started.");

            } catch (Exception exception) {

                getLogger().warning(
                        "BotManager could not start: "
                                + exception.getMessage()
                );
            }
        }

        // Start AI controller
        if (aiController != null) {

            try {

                aiController.start();

                getLogger().info("AIController started.");

            } catch (Exception exception) {

                getLogger().warning(
                        "AIController could not start: "
                                + exception.getMessage()
                );
            }
        }

        // Start chat manager
        if (chatManager != null) {

            try {

                chatManager.start();

                getLogger().info("ChatManager started.");

            } catch (Exception exception) {

                getLogger().warning(
                        "ChatManager could not start: "
                                + exception.getMessage()
                );
            }
        }

        // Start command manager
        if (botCommandManager != null) {

            try {

                botCommandManager.start();

                getLogger().info("BotCommandManager started.");

            } catch (Exception exception) {

                getLogger().warning(
                        "BotCommandManager could not start: "
                                + exception.getMessage()
                );
            }
        }
    }

    /**
     * Saves a resource from the JAR only if it doesn't already exist.
     */
    private void saveResourceIfMissing(String fileName) {

        File file = new File(getDataFolder(), fileName);

        if (!file.exists()) {

            try {

                saveResource(fileName, false);

                getLogger().info(
                        "Created default " + fileName
                );

            } catch (IllegalArgumentException exception) {

                getLogger().warning(
                        "Resource not found in plugin JAR: "
                                + fileName
                );
            }
        }
    }

    /**
     * Reload all plugin configuration files.
     */
    public void reloadFlameBotAI() {

        reloadConfig();

        if (botManager != null) {

            try {
                botManager.reload();
            } catch (Exception exception) {
                getLogger().warning(
                        "BotManager reload failed: "
                                + exception.getMessage()
                );
            }
        }

        if (chatManager != null) {

            try {
                chatManager.reload();
            } catch (Exception exception) {
                getLogger().warning(
                        "ChatManager reload failed: "
                                + exception.getMessage()
                );
            }
        }

        if (botCommandManager != null) {

            try {
                botCommandManager.reload();
            } catch (Exception exception) {
                getLogger().warning(
                        "BotCommandManager reload failed: "
                                + exception.getMessage()
                );
            }
        }

        if (aiController != null) {

            try {
                aiController.reload();
            } catch (Exception exception) {
                getLogger().warning(
                        "AIController reload failed: "
                                + exception.getMessage()
                );
            }
        }

        getLogger().info("FlameBotAI configuration reloaded.");
    }

    /**
     * Get the main plugin instance.
     */
    public static FlameBotAI getInstance() {
        return instance;
    }

    /**
     * Get BotManager.
     */
    public BotManager getBotManager() {
        return botManager;
    }

    /**
     * Get AIController.
     */
    public AIController getAIController() {
        return aiController;
    }

    /**
     * Get ChatManager.
     */
    public ChatManager getChatManager() {
        return chatManager;
    }

    /**
     * Get BotCommandManager.
     */
    public BotCommandManager getBotCommandManager() {
        return botCommandManager;
    }

    /**
     * Get NPCManager.
     */
    public NPCManager getNPCManager() {
        return npcManager;
    }
}