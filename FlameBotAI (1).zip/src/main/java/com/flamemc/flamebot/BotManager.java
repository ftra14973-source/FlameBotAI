package com.flamemc.flamebot;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Central manager for all FlameBotAI bots.
 */
public class BotManager {

    private final FlameBotAI plugin;

    private final Map<UUID, Bot> bots = new LinkedHashMap<>();

    private File botsFile;
    private YamlConfiguration botsConfig;

    private boolean started = false;

    public BotManager(FlameBotAI plugin) {

        if (plugin == null) {
            throw new IllegalArgumentException(
                    "FlameBotAI plugin cannot be null."
            );
        }

        this.plugin = plugin;

        loadConfiguration();
        loadBots();
    }

    // =========================================================
    // START / SHUTDOWN
    // =========================================================

    public void start() {

        if (started) {
            return;
        }

        started = true;

        plugin.getLogger().info(
                "BotManager started with "
                        + bots.size()
                        + " configured bots."
        );
    }

    public void shutdown() {

        if (!started && bots.isEmpty()) {
            return;
        }

        for (Bot bot : bots.values()) {

            try {
                despawnBot(bot);
            } catch (Exception exception) {

                plugin.getLogger().warning(
                        "Failed to despawn "
                                + bot.getName()
                                + ": "
                                + exception.getMessage()
                );
            }
        }

        saveBotLocations();

        bots.clear();
        started = false;

        plugin.getLogger().info(
                "BotManager shut down."
        );
    }

    // =========================================================
    // CONFIGURATION
    // =========================================================

    private void loadConfiguration() {

        botsFile = new File(
                plugin.getDataFolder(),
                "bots.yml"
        );

        if (!botsFile.exists()) {

            plugin.saveResource(
                    "bots.yml",
                    false
            );
        }

        botsConfig =
                YamlConfiguration.loadConfiguration(
                        botsFile
                );
    }

    public void reload() {

        loadConfiguration();

        Map<String, Bot> existingBots =
                new LinkedHashMap<>();

        for (Bot bot : bots.values()) {

            existingBots.put(
                    bot.getName().toLowerCase(),
                    bot
            );
        }

        bots.clear();

        loadBotsFromConfiguration(
                existingBots
        );

        plugin.getLogger().info(
                "BotManager reloaded. Loaded "
                        + bots.size()
                        + " bots."
        );
    }

    // =========================================================
    // BOT LOADING
    // =========================================================

    private void loadBots() {

        loadBotsFromConfiguration(
                Collections.emptyMap()
        );
    }

    private void loadBotsFromConfiguration(
            Map<String, Bot> existingBots
    ) {

        /*
         * Expected format:
         *
         * bots:
         *   - name: Itz_beast
         *     role: PVP
         */

        for (Map<?, ?> map :
                botsConfig.getMapList("bots")) {

            Object nameObject =
                    map.get("name");

            if (nameObject == null) {
                continue;
            }

            String name =
                    String.valueOf(
                            nameObject
                    ).trim();

            if (name.isBlank()) {
                continue;
            }

            String roleText =
                    map.containsKey("role")
                            ? String.valueOf(
                                    map.get("role")
                            )
                            : "GRINDER";

            BotRole role =
                    BotRole.fromString(
                            roleText
                    );

            Bot bot =
                    existingBots.get(
                            name.toLowerCase()
                    );

            if (bot == null) {

                createBot(
                        name,
                        role
                );

            } else {

                bot.getProfile().setRole(role);

                bots.put(
                        bot.getId(),
                        bot
                );
            }
        }
    }

    // =========================================================
    // CREATE / REGISTER
    // =========================================================

    public Bot createBot(
            String name,
            BotRole role
    ) {

        if (name == null || name.isBlank()) {

            throw new IllegalArgumentException(
                    "Bot name cannot be empty."
            );
        }

        if (role == null) {
            role = BotRole.GRINDER;
        }

        Bot existing =
                getBot(name);

        if (existing != null) {
            return existing;
        }

        BotProfile profile =
                createProfile(
                        name,
                        role
                );

        Bot bot =
                new Bot(profile);

        bots.put(
                bot.getId(),
                bot
        );

        plugin.getLogger().info(
                "Registered bot: "
                        + name
                        + " ["
                        + role
                        + "]"
        );

        return bot;
    }

    private BotProfile createProfile(
            String name,
            BotRole role
    ) {

        BotProfile profile =
                new BotProfile(
                        name,
                        role
                );

        switch (role) {

            case PVP -> {

                profile.setIntelligence(85);
                profile.setAggression(90);
                profile.setFriendliness(35);
                profile.setBravery(95);
                profile.setCuriosity(70);
                profile.setWorkPriority(50);
                profile.setSocialLevel(55);

                profile.setPersonality(
                        "competitive_pvp"
                );

                profile.setCurrentObjective(
                        "find opponents and improve combat"
                );
            }

            case GRINDER -> {

                profile.setIntelligence(75);
                profile.setAggression(35);
                profile.setFriendliness(60);
                profile.setBravery(70);
                profile.setCuriosity(75);
                profile.setWorkPriority(95);
                profile.setSocialLevel(50);

                profile.setPersonality(
                        "resource_grinder"
                );

                profile.setCurrentObjective(
                        "collect resources"
                );
            }

            case MONEY -> {

                profile.setIntelligence(90);
                profile.setAggression(25);
                profile.setFriendliness(60);
                profile.setBravery(65);
                profile.setCuriosity(70);
                profile.setWorkPriority(100);
                profile.setSocialLevel(55);

                profile.setPersonality(
                        "money_grinder"
                );

                profile.setCurrentObjective(
                        "farm bamboo and make profit"
                );

                profile.remember(
                        "preferred_sell_command",
                        "/sellgui"
                );

                profile.remember(
                        "forbidden_sell_command",
                        "/sell"
                );

                profile.remember(
                        "preferred_resource",
                        "BAMBOO"
                );
            }

            case MYSTERIOUS -> {

                profile.setIntelligence(100);
                profile.setAggression(40);
                profile.setFriendliness(20);
                profile.setBravery(85);
                profile.setCuriosity(100);
                profile.setWorkPriority(60);
                profile.setSocialLevel(15);

                profile.setPersonality(
                        "mysterious"
                );

                profile.setCurrentObjective(
                        "unknown"
                );

                profile.remember(
                        "hidden_objective",
                        true
                );
            }
        }

        return profile;
    }

    public boolean removeBot(String name) {

        Bot bot = getBot(name);

        if (bot == null) {
            return false;
        }

        despawnBot(bot);

        bots.remove(
                bot.getId()
        );

        return true;
    }

    // =========================================================
    // SPAWN
    // =========================================================

    public boolean spawnBot(
            String name,
            Location location
    ) {

        Bot bot = getBot(name);

        if (bot == null) {
            return false;
        }

        return spawnBot(
                bot,
                location
        );
    }

    public boolean spawnBot(
            Bot bot,
            Location location
    ) {

        if (bot == null || location == null) {
            return false;
        }

        if (location.getWorld() == null) {
            return false;
        }

        if (!bot.getProfile().isEnabled()) {
            return false;
        }

        if (bot.isSpawned()
                && bot.isEntityAlive()) {

            return true;
        }

        NPCManager npcManager =
                plugin.getNPCManager();

        if (npcManager == null) {

            plugin.getLogger().warning(
                    "NPCManager is not available."
            );

            return false;
        }

        try {

            Entity entity =
                    npcManager.spawn(
                            bot,
                            location
                    );

            if (entity == null) {
                return false;
            }

            bot.setSpawnLocation(
                    location
            );

            bot.setLocation(
                    location
            );

            bot.setEntity(
                    entity
            );

            bot.setOnline(true);
            bot.setAlive(true);
            bot.setSpawned(true);

            bot.setState(
                    BotState.IDLE
            );

            plugin.getLogger().info(
                    "Spawned bot: "
                            + bot.getName()
            );

            return true;

        } catch (Exception exception) {

            plugin.getLogger().warning(
                    "Could not spawn "
                            + bot.getName()
                            + ": "
                            + exception.getMessage()
            );

            return false;
        }
    }

    // =========================================================
    // DESPAWN
    // =========================================================

    public boolean despawnBot(
            String name
    ) {

        Bot bot = getBot(name);

        if (bot == null) {
            return false;
        }

        return despawnBot(bot);
    }

    public boolean despawnBot(
            Bot bot
    ) {

        if (bot == null) {
            return false;
        }

        NPCManager npcManager =
                plugin.getNPCManager();

        try {

            if (npcManager != null) {

                npcManager.despawn(
                        bot
                );
            }

        } catch (Exception exception) {

            plugin.getLogger().warning(
                    "NPC despawn failed for "
                            + bot.getName()
                            + ": "
                            + exception.getMessage()
            );
        }

        bot.setEntity(null);
        bot.setSpawned(false);
        bot.setOnline(false);
        bot.clearTarget();
        bot.clearFollowing();

        if (bot.isAlive()) {
            bot.setState(
                    BotState.IDLE
            );
        }

        return true;
    }

    // =========================================================
    // MASS SPAWN / DESPAWN
    // =========================================================

    public int spawnAll(
            Location location
    ) {

        if (location == null) {
            return 0;
        }

        int spawned = 0;

        for (Bot bot : bots.values()) {

            if (!bot.getProfile().isEnabled()) {
                continue;
            }

            if (spawnBot(
                    bot,
                    location
            )) {

                spawned++;
            }
        }

        return spawned;
    }

    public int despawnAll() {

        int count = 0;

        for (Bot bot : bots.values()) {

            if (bot.isSpawned()) {

                if (despawnBot(bot)) {
                    count++;
                }
            }
        }

        return count;
    }

    // =========================================================
    // LOOKUP
    // =========================================================

    public Bot getBot(
            String name
    ) {

        if (name == null || name.isBlank()) {
            return null;
        }

        for (Bot bot : bots.values()) {

            if (bot.getName()
                    .equalsIgnoreCase(name)) {

                return bot;
            }
        }

        return null;
    }

    public Bot getBot(
            UUID uuid
    ) {

        if (uuid == null) {
            return null;
        }

        return bots.get(uuid);
    }

    public Bot getBotByEntity(
            UUID entityId
    ) {

        if (entityId == null) {
            return null;
        }

        for (Bot bot : bots.values()) {

            Entity entity =
                    bot.getEntity();

            if (entity != null
                    && entity.getUniqueId()
                    .equals(entityId)) {

                return bot;
            }
        }

        return null;
    }

    public boolean isBot(
            Entity entity
    ) {

        if (entity == null) {
            return false;
        }

        return getBotByEntity(
                entity.getUniqueId()
        ) != null;
    }

    public boolean isBot(
            Player player
    ) {

        if (player == null) {
            return false;
        }

        return isBot(
                (Entity) player
        );
    }

    // =========================================================
    // COLLECTIONS
    // =========================================================

    public Collection<Bot> getBots() {

        return Collections.unmodifiableCollection(
                bots.values()
        );
    }

    public int getBotCount() {
        return bots.size();
    }

    public int getOnlineBotCount() {

        int count = 0;

        for (Bot bot : bots.values()) {

            if (bot.isOnline()
                    && bot.isSpawned()
                    && bot.isEntityAlive()) {

                count++;
            }
        }

        return count;
    }

    public int getAliveBotCount() {

        int count = 0;

        for (Bot bot : bots.values()) {

            if (bot.isAlive()) {
                count++;
            }
        }

        return count;
    }
        // =========================================================
    // ROLE LOOKUPS
    // =========================================================

    public Collection<Bot> getBotsByRole(BotRole role) {

        if (role == null) {
            return Collections.emptyList();
        }

        Map<UUID, Bot> result = new LinkedHashMap<>();

        for (Bot bot : bots.values()) {

            if (bot.getRole() == role) {
                result.put(
                        bot.getId(),
                        bot
                );
            }
        }

        return Collections.unmodifiableCollection(
                result.values()
        );
    }

    public Bot getRandomBot() {

        if (bots.isEmpty()) {
            return null;
        }

        java.util.List<Bot> list =
                new java.util.ArrayList<>(
                        bots.values()
                );

        int index =
                (int) (Math.random() * list.size());

        return list.get(index);
    }

    // =========================================================
    // LOCATION UPDATES
    // =========================================================

    public void updateLocations() {

        for (Bot bot : bots.values()) {

            if (!bot.isSpawned()) {
                continue;
            }

            Entity entity =
                    bot.getEntity();

            if (entity == null
                    || !entity.isValid()) {

                continue;
            }

            bot.setLocation(
                    entity.getLocation()
            );
        }
    }

    // =========================================================
    // NEAREST PLAYER
    // =========================================================

    public Player findNearestPlayer(
            Bot bot,
            double maxDistance
    ) {

        if (bot == null
                || !bot.isSpawned()
                || bot.getLocation() == null) {

            return null;
        }

        Location botLocation =
                bot.getLocation();

        Player nearest = null;
        double nearestDistanceSquared =
                maxDistance * maxDistance;

        for (Player player :
                Bukkit.getOnlinePlayers()) {

            if (player == null
                    || !player.isOnline()
                    || player.isDead()) {

                continue;
            }

            Location playerLocation =
                    player.getLocation();

            if (playerLocation.getWorld() == null
                    || botLocation.getWorld() == null) {

                continue;
            }

            if (!playerLocation.getWorld()
                    .equals(botLocation.getWorld())) {

                continue;
            }

            double distanceSquared;

            try {

                distanceSquared =
                        botLocation.distanceSquared(
                                playerLocation
                        );

            } catch (IllegalArgumentException exception) {

                continue;
            }

            if (distanceSquared
                    <= nearestDistanceSquared) {

                nearestDistanceSquared =
                        distanceSquared;

                nearest = player;
            }
        }

        return nearest;
    }

    // =========================================================
    // DEFAULT SPAWN
    // =========================================================

    public Location getDefaultSpawnLocation() {

        World world =
                Bukkit.getWorlds()
                        .stream()
                        .findFirst()
                        .orElse(null);

        if (world == null) {
            return null;
        }

        Location spawn =
                world.getSpawnLocation();

        return spawn.clone().add(
                0.5,
                0.0,
                0.5
        );
    }

    public boolean spawnAtDefaultSpawn(
            String name
    ) {

        Location location =
                getDefaultSpawnLocation();

        if (location == null) {

            plugin.getLogger().warning(
                    "No default world/spawn location found."
            );

            return false;
        }

        return spawnBot(
                name,
                location
        );
    }

    // =========================================================
    // PERSISTENT LOCATIONS
    // =========================================================

    public void saveBotLocations() {

        if (botsConfig == null) {
            return;
        }

        for (Bot bot : bots.values()) {

            Location location =
                    bot.getLocation();

            if (location == null) {
                location =
                        bot.getSpawnLocation();
            }

            if (location == null
                    || location.getWorld() == null) {

                continue;
            }

            String path =
                    "locations."
                            + bot.getName();

            botsConfig.set(
                    path + ".world",
                    location.getWorld().getName()
            );

            botsConfig.set(
                    path + ".x",
                    location.getX()
            );

            botsConfig.set(
                    path + ".y",
                    location.getY()
            );

            botsConfig.set(
                    path + ".z",
                    location.getZ()
            );

            botsConfig.set(
                    path + ".yaw",
                    location.getYaw()
            );

            botsConfig.set(
                    path + ".pitch",
                    location.getPitch()
            );
        }

        try {

            botsConfig.save(
                    botsFile
            );

        } catch (IOException exception) {

            plugin.getLogger().warning(
                    "Could not save bot locations: "
                            + exception.getMessage()
            );
        }
    }

    public Location getSavedLocation(
            String name
    ) {

        if (name == null || name.isBlank()) {
            return null;
        }

        String path =
                "locations."
                        + name;

        if (!botsConfig.contains(path)) {
            return null;
        }

        String worldName =
                botsConfig.getString(
                        path + ".world"
                );

        if (worldName == null
                || worldName.isBlank()) {

            return null;
        }

        World world =
                Bukkit.getWorld(
                        worldName
                );

        if (world == null) {
            return null;
        }

        double x =
                botsConfig.getDouble(
                        path + ".x"
                );

        double y =
                botsConfig.getDouble(
                        path + ".y"
                );

        double z =
                botsConfig.getDouble(
                        path + ".z"
                );

        float yaw =
                (float) botsConfig.getDouble(
                        path + ".yaw"
                );

        float pitch =
                (float) botsConfig.getDouble(
                        path + ".pitch"
                );

        return new Location(
                world,
                x,
                y,
                z,
                yaw,
                pitch
        );
    }

    // =========================================================
    // DEBUG INFORMATION
    // =========================================================

    public String getDebugInfo() {

        StringBuilder builder =
                new StringBuilder();

        builder.append(
                "===== FlameBotAI BotManager =====\n"
        );

        builder.append(
                "Started: "
        ).append(
                started
        ).append("\n");

        builder.append(
                "Total Bots: "
        ).append(
                getBotCount()
        ).append("\n");

        builder.append(
                "Online Bots: "
        ).append(
                getOnlineBotCount()
        ).append("\n");

        builder.append(
                "Alive Bots: "
        ).append(
                getAliveBotCount()
        ).append("\n");

        builder.append(
                "\nBots:\n"
        );

        for (Bot bot : bots.values()) {

            builder.append(
                    "- "
            ).append(
                    bot.getName()
            ).append(
                    " | Role="
            ).append(
                    bot.getRole()
            ).append(
                    " | State="
            ).append(
                    bot.getState()
            ).append(
                    " | Spawned="
            ).append(
                    bot.isSpawned()
            ).append(
                    " | Online="
            ).append(
                    bot.isOnline()
            );

            if (bot.getLocation() != null) {

                builder.append(
                        " | Location="
                ).append(
                        formatLocation(
                                bot.getLocation()
                        )
                );
            }

            builder.append("\n");
        }

        return builder.toString();
    }

    private String formatLocation(
            Location location
    ) {

        if (location == null) {
            return "unknown";
        }

        String world =
                location.getWorld() == null
                        ? "unknown"
                        : location.getWorld().getName();

        return world
                + " "
                + String.format(
                        "%.1f, %.1f, %.1f",
                        location.getX(),
                        location.getY(),
                        location.getZ()
                );
    }

    // =========================================================
    // MANAGER GETTERS
    // =========================================================

    public FlameBotAI getPlugin() {
        return plugin;
    }

    public boolean isStarted() {
        return started;
    }

    public File getBotsFile() {
        return botsFile;
    }

    public YamlConfiguration getBotsConfig() {
        return botsConfig;
    }

    // =========================================================
    // END
    // =========================================================
}