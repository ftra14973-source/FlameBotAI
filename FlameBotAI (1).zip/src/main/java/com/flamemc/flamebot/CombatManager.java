package com.flamemc.flamebot;

import org.bukkit.EntityEffect;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** Combat engine for player-type NPCs. */
public final class CombatManager {
    private final FlameBotAI plugin; private final BotManager botManager;
    private static final double RANGE=3.2, SEARCH=24.0; private static final long COOLDOWN=650L;
    public CombatManager(FlameBotAI plugin,BotManager botManager){this.plugin=plugin;this.botManager=botManager;}
    public Player findNearestPlayer(Bot bot){if(bot==null||bot.getLocation()==null)return null;Player best=null;double bd=SEARCH;for(Player p:bot.getLocation().getWorld().getPlayers()){if(!p.isOnline()||p.isDead()||!canAttackPlayer(bot,p))continue;double d=bot.getLocation().distance(p.getLocation());if(d<bd){bd=d;best=p;}}return best;}
    public LivingEntity findNearestMob(Bot bot){if(bot==null||bot.getLocation()==null)return null;LivingEntity best=null;double bd=SEARCH;for(LivingEntity e:bot.getLocation().getWorld().getLivingEntities()){if(!(e instanceof Monster)||e.isDead())continue;double d=bot.getLocation().distance(e.getLocation());if(d<bd){bd=d;best=e;}}return best;}
    public Entity selectBestTarget(Bot bot){Player p=findNearestPlayer(bot);LivingEntity m=findNearestMob(bot);if(p==null)return m;if(m==null)return p;return bot.getLocation().distance(p.getLocation())<=bot.getLocation().distance(m.getLocation())?p:m;}
    public boolean startCombat(Bot bot,Entity target){if(bot==null||!(target instanceof LivingEntity l)||l.isDead())return false;bot.setTargetId(target.getUniqueId());bot.setState(target instanceof Player?BotState.PVP_COMBAT:BotState.MOB_COMBAT);return true;}
    public void stopCombat(Bot bot){if(bot!=null){bot.clearTarget();bot.setState(BotState.IDLE);bot.setCurrentTask("Idle");}}
    public LivingEntity getCurrentTarget(Bot bot){if(bot==null||bot.getTargetId()==null)return null;Entity e=findEntity(bot,bot.getTargetId());return e instanceof LivingEntity l&&!l.isDead()?l:null;}
    private Entity findEntity(Bot bot,UUID id){if(bot==null||bot.getLocation()==null)return null;for(Entity e:bot.getLocation().getWorld().getEntities())if(e.getUniqueId().equals(id))return e;return null;}
    public boolean attack(Bot bot,LivingEntity target){if(bot==null||target==null||target.isDead()||!isInAttackRange(bot,target)||!canAttackNow(bot))return false;double damage=bot.isPvPBot()?3.0:2.5;target.damage(damage,bot.getEntity());bot.remember("last_attack",System.currentTimeMillis());try{if(bot.getEntity()!=null)bot.getEntity().playEffect(EntityEffect.HURT);}catch(Exception ignored){}return true;}
    public boolean attackPlayer(Bot bot,Player p){return canAttackPlayer(bot,p)&&attack(bot,p);}
    public boolean attackMob(Bot bot,LivingEntity mob){return mob instanceof Monster&&attack(bot,mob);}
    public boolean isInAttackRange(Bot bot,LivingEntity target){return bot!=null&&bot.getLocation()!=null&&target!=null&&bot.getLocation().getWorld().equals(target.getWorld())&&bot.getLocation().distance(target.getLocation())<=RANGE;}
    public boolean canAttackNow(Bot bot){if(bot==null)return false;Object v=bot.recall("last_attack");return !(v instanceof Number n)||System.currentTimeMillis()-n.longValue()>=COOLDOWN;}
    public boolean canAttackPlayer(Bot bot,Player p){if(bot==null||p==null||p.isDead()||!p.isOnline())return false;Bot other=botManager.getBotByEntity(p);if(other!=null)return false;return !"true".equalsIgnoreCase(String.valueOf(bot.recall("friendly_"+p.getUniqueId())));}
    public List<LivingEntity> getNearbyEnemies(Bot bot,double radius){List<LivingEntity> out=new ArrayList<>();if(bot==null||bot.getLocation()==null)return out;for(LivingEntity e:bot.getLocation().getWorld().getLivingEntities()){if(e instanceof Player p){if(!canAttackPlayer(bot,p))continue;}else if(!(e instanceof Monster))continue;if(bot.getLocation().distance(e.getLocation())<=radius)out.add(e);}out.sort(Comparator.comparingDouble(e->bot.getLocation().distance(e.getLocation())));return out;}
    public boolean isInDanger(Bot bot){return bot!=null&&(bot.getHealth()<=6||bot.getFoodLevel()<=6||getNearbyEnemies(bot,8).size()>=4);}
    public Location findEscapeLocation(Bot bot){if(bot==null||bot.getLocation()==null)return null;Location c=bot.getLocation(),best=null;double score=-1;World w=c.getWorld();for(int i=0;i<12;i++){double a=Math.random()*Math.PI*2,d=8+Math.random()*12;int x=c.getBlockX()+(int)(Math.cos(a)*d),z=c.getBlockZ()+(int)(Math.sin(a)*d),y=w.getHighestBlockYAt(x,z);Location l=new Location(w,x+.5,y+1,z+.5);if(l.getBlock().isPassable()&&l.clone().subtract(0,1,0).getBlock().getType().isSolid()&&d>score){score=d;best=l;}}return best;}
    public void tickCombat(Bot bot){LivingEntity t=getCurrentTarget(bot);if(t==null){t=selectBestTarget(bot) instanceof LivingEntity l?l:null;if(t==null){stopCombat(bot);return;}startCombat(bot,t);}if(isInAttackRange(bot,t))attack(bot,t);else if(plugin.getNPCManager()!=null)plugin.getNPCManager().move(bot,t.getLocation());}
    public FlameBotAI getPlugin(){return plugin;} public BotManager getBotManager(){return botManager;} public double getAttackRange(){return RANGE;}
}
