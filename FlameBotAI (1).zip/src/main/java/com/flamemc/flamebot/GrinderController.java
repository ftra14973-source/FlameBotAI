package com.flamemc.flamebot;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Monster;

/** Mining/farming/mob-grinding helper. */
public final class GrinderController {
    private final FlameBotAI plugin;
    private final ResourceManager resources;
    private final CombatManager combat;
    public GrinderController(FlameBotAI plugin){this.plugin=plugin;this.resources=new ResourceManager(plugin);this.combat=new CombatManager(plugin,plugin.getBotManager());}
    public Location findOre(Bot bot){
        Material[] ores={Material.IRON_ORE,Material.COAL_ORE,Material.COPPER_ORE,Material.GOLD_ORE,Material.REDSTONE_ORE,Material.LAPIS_ORE,Material.DIAMOND_ORE};
        for(Material m:ores){Location l=resources.findNearest(bot,m,12);if(l!=null)return l;} return null;
    }
    public void tick(Bot bot){if(bot==null||!bot.isGrinderBot())return; var mob=combat.findNearestMob(bot); if(mob instanceof Monster && bot.getLocation().distance(mob.getLocation())<10){combat.startCombat(bot,mob);combat.tickCombat(bot);return;} Location ore=findOre(bot); if(ore!=null){bot.setState(BotState.MINING);bot.setCurrentTask("Mining");if(bot.getLocation().distance(ore)>3&&plugin.getNPCManager()!=null)plugin.getNPCManager().move(bot,ore);else ore.getBlock().breakNaturally();}else bot.setCurrentTask("Exploring for resources");}
    public ResourceManager getResources(){return resources;}
}
