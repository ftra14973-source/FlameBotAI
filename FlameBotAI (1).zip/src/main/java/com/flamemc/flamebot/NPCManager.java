package com.flamemc.flamebot;

import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Owns all Citizens PLAYER NPCs used by FlameBotAI.
 */
public final class NPCManager {

    private final FlameBotAI plugin;
    private final Map<UUID, NPC> npcs = new HashMap<>();

    public NPCManager(FlameBotAI plugin) {
        this.plugin = plugin;
    }

    public boolean isCitizensReady() {
        Plugin citizens = Bukkit.getPluginManager().getPlugin("Citizens");
        return citizens != null && citizens.isEnabled() && CitizensAPI.hasImplementation();
    }

    public Entity spawn(Bot bot, Location location) {
        if (bot == null || location == null || !isCitizensReady()) {
            return null;
        }

        despawn(bot);

        NPC npc = NPCAdapter.create(bot, location);
        if (npc == null || npc.getEntity() == null) {
            return null;
        }

        npcs.put(bot.getId(), npc);
        return npc.getEntity();
    }

    public void move(Bot bot, Location target) {
        NPC npc = getNPC(bot);
        if (npc == null || !npc.isSpawned() || target == null) {
            return;
        }

        npc.getNavigator().setTarget(target);
    }

    public void stop(Bot bot) {
        NPC npc = getNPC(bot);
        if (npc != null && npc.isSpawned()) {
            npc.getNavigator().cancelNavigation();
        }
    }

    public void despawn(Bot bot) {
        if (bot == null) {
            return;
        }

        NPC npc = npcs.remove(bot.getId());
        if (npc == null) {
            return;
        }

        try {
            if (npc.isSpawned()) {
                npc.despawn();
            }
        } finally {
            if (CitizensAPI.hasImplementation()) {
                CitizensAPI.getNPCRegistry().deregister(npc);
            }
        }
    }

    public NPC getNPC(Bot bot) {
        return bot == null ? null : npcs.get(bot.getId());
    }

    public NPC getNPC(UUID botId) {
        return botId == null ? null : npcs.get(botId);
    }

    public Bot getBot(Entity entity) {
        if (entity == null) {
            return null;
        }

        for (Map.Entry<UUID, NPC> entry : npcs.entrySet()) {
            NPC npc = entry.getValue();
            if (npc != null && npc.getEntity() != null
                    && npc.getEntity().getUniqueId().equals(entity.getUniqueId())) {
                return plugin.getBotManager().getBot(entry.getKey());
            }
        }

        return null;
    }

    public void shutdown() {
        for (NPC npc : npcs.values()) {
            try {
                if (npc != null && npc.isSpawned()) {
                    npc.despawn();
                }
                if (npc != null && CitizensAPI.hasImplementation()) {
                    CitizensAPI.getNPCRegistry().deregister(npc);
                }
            } catch (Exception ignored) {
            }
        }
        npcs.clear();
    }
}
