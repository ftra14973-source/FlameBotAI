package com.flamemc.flamebot;

import org.bukkit.Location;
import org.bukkit.entity.Entity;

/** Simple spawn helper for player-type Citizens NPCs. */
public final class NPCSpawner {

    private NPCSpawner() {
    }

    public static Entity spawn(NPCManager manager, Bot bot, Location location) {
        return manager == null ? null : manager.spawn(bot, location);
    }
}
