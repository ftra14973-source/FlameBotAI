package com.flamemc.flamebot;

import java.util.concurrent.ThreadLocalRandom;

/** Natural short Hinglish response pool. */
public final class HinglishChat {
    private HinglishChat(){}
    private static final String[] GENERAL={"haan bhai","acha 😂","ruk check karta hu","lol kya scene hai","main abhi aa raha hu","haan bol","sahi hai bro","ek sec"};
    private static final String[] PVP={"fight karega?","aa ja bhai 😈","gg bro","ruk heal kar raha hu","nice combo"};
    public static String random(BotRole role){String[] a=role==BotRole.PVP?PVP:GENERAL;return a[ThreadLocalRandom.current().nextInt(a.length)];}
}
