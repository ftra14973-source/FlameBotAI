package com.flamemc.flamebot;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Represents one FlameBotAI bot.
 *
 * This class stores the bot's profile, state, location,
 * target and runtime information.
 */
public class Bot {

    private final UUID id;
    private final BotProfile profile;

    private BotState state;

    private Location location;
    private Location spawnLocation;

    private UUID targetId;
    private UUID followingId;

    private boolean online;
    private boolean alive;
    private boolean spawned;

    private long stateStartedAt;
    private long lastActionAt;
    private long lastChatAt;
    private long lastCommandAt;
    private long lastDamageAt;

    private int health;
    private int foodLevel;

    private String currentTask;
    private String lastMessage;
    private String lastCommand;

    private Entity entity;

    /**
     * Creates a bot using its profile.
     */
    public Bot(BotProfile profile) {

        if (profile == null) {
            throw new IllegalArgumentException(
                    "BotProfile cannot be null"
            );
        }

        this.id = UUID.randomUUID();
        this.profile = profile;

        this.state = BotState.IDLE;

        this.online = false;
        this.alive = true;
        this.spawned = false;

        this.health = 20;
        this.foodLevel = 20;

        this.currentTask = "Idle";
        this.lastMessage = "";
        this.lastCommand = "";

        this.stateStartedAt = System.currentTimeMillis();
        this.lastActionAt = 0L;
        this.lastChatAt = 0L;
        this.lastCommandAt = 0L;
        this.lastDamageAt = 0L;
    }

    // =========================================================
    // BASIC INFORMATION
    // =========================================================

    public UUID getId() {
        return id;
    }

    public BotProfile getProfile() {
        return profile;
    }

    public String getName() {
        return profile.getName();
    }

    public BotRole getRole() {
        return profile.getRole();
    }

    // =========================================================
    // STATE
    // =========================================================

    public BotState getState() {
        return state;
    }

    /**
     * Changes the current bot state.
     */
    public void setState(BotState state) {

        if (state == null) {
            state = BotState.IDLE;
        }

        this.state = state;
        this.stateStartedAt = System.currentTimeMillis();
    }

    /**
     * Returns how long the bot has been in its current state.
     */
    public long getStateDurationMillis() {

        return System.currentTimeMillis() - stateStartedAt;
    }

    /**
     * Returns current state duration in seconds.
     */
    public long getStateDurationSeconds() {

        return getStateDurationMillis() / 1000L;
    }

    // =========================================================
    // LOCATION
    // =========================================================

    public Location getLocation() {

        return location == null
                ? null
                : location.clone();
    }

    public void setLocation(Location location) {

        this.location = location == null
                ? null
                : location.clone();

        if (location != null) {
            profile.setLastLocation(location);
        }
    }

    public Location getSpawnLocation() {

        return spawnLocation == null
                ? null
                : spawnLocation.clone();
    }

    public void setSpawnLocation(Location spawnLocation) {

        this.spawnLocation = spawnLocation == null
                ? null
                : spawnLocation.clone();
    }

    /**
     * Updates the bot's current location from its entity.
     */
    public void updateLocation() {

        if (entity != null && !entity.isDead()) {
            setLocation(entity.getLocation());
        }
    }

    /**
     * Checks whether the bot has a valid location.
     */
    public boolean hasLocation() {
        return location != null;
    }

    // =========================================================
    // ENTITY
    // =========================================================

    public Entity getEntity() {
        return entity;
    }

    public void setEntity(Entity entity) {

        this.entity = entity;

        if (entity != null) {
            setLocation(entity.getLocation());
            spawned = true;
        } else {
            spawned = false;
        }
    }

    public boolean hasEntity() {
        return entity != null;
    }

    public boolean isEntityAlive() {

        return entity != null
                && !entity.isDead();
    }

    // =========================================================
    // ONLINE / SPAWN STATUS
    // =========================================================

    public boolean isOnline() {
        return online;
    }

    public void setOnline(boolean online) {
        this.online = online;
    }

    public boolean isAlive() {
        return alive;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;

        if (!alive) {
            setState(BotState.DEAD);
        }
    }

    public boolean isSpawned() {
        return spawned;
    }

    public void setSpawned(boolean spawned) {
        this.spawned = spawned;
    }

    // =========================================================
    // TARGET SYSTEM
    // =========================================================

    public UUID getTargetId() {
        return targetId;
    }

    public void setTargetId(UUID targetId) {
        this.targetId = targetId;
    }

    public void clearTarget() {
        this.targetId = null;
    }

    public boolean hasTarget() {
        return targetId != null;
    }

    /**
     * Returns the current target if it is a real online player.
     */
    public Player getTargetPlayer() {

        if (targetId == null) {
            return null;
        }

        return org.bukkit.Bukkit
                .getPlayer(targetId);
    }

    // =========================================================
    // FOLLOW SYSTEM
    // =========================================================

    public UUID getFollowingId() {
        return followingId;
    }

    public void setFollowingId(UUID followingId) {
        this.followingId = followingId;

        if (followingId != null) {
            setState(BotState.FOLLOWING_PLAYER);
        }
    }

    public void clearFollowing() {
        this.followingId = null;
    }

    public boolean isFollowing() {
        return followingId != null;
    }

    /**
     * Gets the player the bot is following.
     */
    public Player getFollowingPlayer() {

        if (followingId == null) {
            return null;
        }

        return org.bukkit.Bukkit
                .getPlayer(followingId);
    }

    // =========================================================
    // TASK SYSTEM
    // =========================================================

    public String getCurrentTask() {
        return currentTask;
    }

    public void setCurrentTask(String currentTask) {

        if (currentTask == null || currentTask.isBlank()) {
            this.currentTask = "Idle";
        } else {
            this.currentTask = currentTask;
        }
    }

    public boolean hasTask() {

        return currentTask != null
                && !currentTask.isBlank()
                && !currentTask.equalsIgnoreCase("Idle");
    }

    public void clearTask() {

        this.currentTask = "Idle";
        setState(BotState.IDLE);
    }

    // =========================================================
    // HEALTH / FOOD
    // =========================================================

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {

        this.health = Math.max(
                0,
                Math.min(20, health)
        );

        if (this.health <= 0) {
            setAlive(false);
        }
    }

    public void damage(int amount) {

        if (amount <= 0 || !alive) {
            return;
        }

        setHealth(health - amount);
        lastDamageAt = System.currentTimeMillis();
    }

    public void heal(int amount) {

        if (amount <= 0 || !alive) {
            return;
        }

        setHealth(health + amount);
    }

    public int getFoodLevel() {
        return foodLevel;
    }

    public void setFoodLevel(int foodLevel) {

        this.foodLevel = Math.max(
                0,
                Math.min(20, foodLevel)
        );
    }

    // =========================================================
    // TIMERS
    // =========================================================

    public long getLastActionAt() {
        return lastActionAt;
    }

    public void markAction() {
        lastActionAt = System.currentTimeMillis();
    }

    public long getLastChatAt() {
        return lastChatAt;
    }

    public void markChat() {
        lastChatAt = System.currentTimeMillis();
    }

    public long getLastCommandAt() {
        return lastCommandAt;
    }

    public void markCommand() {
        lastCommandAt = System.currentTimeMillis();
    }

    public long getLastDamageAt() {
        return lastDamageAt;
    }

    /**
     * Checks whether enough time has passed since an action.
     */
    public boolean canAct(long cooldownMillis) {

        return System.currentTimeMillis()
                - lastActionAt
                >= cooldownMillis;
    }

    /**
     * Checks whether enough time has passed since chat.
     */
    public boolean canChat(long cooldownMillis) {

        return System.currentTimeMillis()
                - lastChatAt
                >= cooldownMillis;
    }

    /**
     * Checks whether enough time has passed since command.
     */
    public boolean canUseCommand(long cooldownMillis) {

        return System.currentTimeMillis()
                - lastCommandAt
                >= cooldownMillis;
    }

    // =========================================================
    // CHAT / COMMAND MEMORY
    // =========================================================

    public String getLastMessage() {
        return lastMessage;
    }

    public void setLastMessage(String lastMessage) {

        this.lastMessage =
                lastMessage == null
                        ? ""
                        : lastMessage;
    }

    public String getLastCommand() {
        return lastCommand;
    }

    public void setLastCommand(String lastCommand) {

        this.lastCommand =
                lastCommand == null
                        ? ""
                        : lastCommand;
    }

    // =========================================================
    // ROLE HELPERS
    // =========================================================

    public boolean isPvPBot() {
        return profile.isPvPBot();
    }

    public boolean isGrinderBot() {
        return profile.isGrinderBot();
    }

    public boolean isMoneyBot() {
        return profile.isMoneyBot();
    }

    public boolean isMysteriousBot() {
        return profile.isMysteriousBot();
    }

    // =========================================================
    // STATE HELPERS
    // =========================================================

    public boolean isInCombat() {
        return state.isCombat();
    }

    public boolean isWorking() {
        return state.isWorking();
    }

    public boolean isTravelling() {
        return state.isTravelling();
    }

    public boolean isSocial() {
        return state.isSocial();
    }

    public boolean isInactive() {
        return state.isInactive();
    }

    // =========================================================
    // PROFILE MEMORY
    // =========================================================

    /**
     * Saves something to the bot's long-term AI memory.
     */
    public void remember(String key, Object value) {
        profile.remember(key, value);
    }

    public Object recall(String key) {
        return profile.recall(key);
    }

    public boolean remembers(String key) {
        return profile.remembers(key);
    }

    // =========================================================
    // HOME / BASE
    // =========================================================

    public Location getHomeLocation() {
        return profile.getHomeLocation();
    }

    public void setHomeLocation(Location location) {
        profile.setHomeLocation(location);
    }

    public Location getBaseLocation() {
        return profile.getBaseLocation();
    }

    public void setBaseLocation(Location location) {
        profile.setBaseLocation(location);
    }

    public boolean hasHome() {
        return profile.getHomeLocation() != null;
    }

    public boolean hasBase() {
        return profile.getBaseLocation() != null;
    }

    // =========================================================
    // RESET / RESPAWN
    // =========================================================

    /**
     * Resets runtime state after death/respawn.
     */
    public void resetAfterRespawn(Location newLocation) {

        this.health = 20;
        this.foodLevel = 20;

        this.alive = true;
        this.online = true;

        this.targetId = null;
        this.followingId = null;

        this.currentTask = "Idle";

        this.lastMessage = "";
        this.lastCommand = "";

        setLocation(newLocation);
        setState(BotState.RESPAWNING);
    }

    /**
     * Fully resets the bot's temporary AI state.
     */
    public void resetAIState() {

        targetId = null;
        followingId = null;

        currentTask = "Idle";

        setState(BotState.IDLE);
    }

    // =========================================================
    // SUMMARY
    // =========================================================

    public String getSummary() {

        return "Bot{" +
                "name='" + getName() + '\'' +
                ", role=" + getRole() +
                ", state=" + state +
                ", online=" + online +
                ", alive=" + alive +
                ", spawned=" + spawned +
                ", health=" + health +
                ", food=" + foodLevel +
                ", task='" + currentTask + '\'' +
                '}';
    }

    @Override
    public String toString() {
        return getSummary();
    }
}