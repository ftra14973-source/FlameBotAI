package com.flamemc.flamebot;

import org.bukkit.Location;
import org.bukkit.Material;

/** Coordinates simple bot building jobs. */
public final class BuildManager {
    private final FlameBotAI plugin; private final BaseBuilder baseBuilder;
    public BuildManager(FlameBotAI plugin){this.plugin=plugin;this.baseBuilder=new BaseBuilder(plugin);}
    public void buildBase(Bot bot, Location location){if(bot==null||!bot.getProfile().canBuild())return;baseBuilder.buildStarterBase(bot,location);}
    public void buildBase(Bot bot){if(bot==null)return;Location l=bot.getBaseLocation();if(l==null)l=bot.getLocation();buildBase(bot,l);}
    public void place(Bot bot, Location location, Material material){if(bot==null||location==null||material==null)return;location.getBlock().setType(material,false);bot.setState(BotState.BUILDING);}
    public BaseBuilder getBaseBuilder(){return baseBuilder;} public FlameBotAI getPlugin(){return plugin;}
}
