package com.flamemc.flamebot;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;

import java.util.ArrayList;
import java.util.List;

/** Finds useful resources around a bot. */
public final class ResourceManager {
    private final FlameBotAI plugin;
    public ResourceManager(FlameBotAI plugin) { this.plugin = plugin; }

    public Location findNearest(Bot bot, Material material, int radius) {
        if (bot == null || bot.getLocation() == null || material == null) return null;
        Location c = bot.getLocation(); Location best = null; double bd = Double.MAX_VALUE;
        int r = Math.max(1, radius);
        for (int x = -r; x <= r; x++) for (int z = -r; z <= r; z++) {
            for (int dy = -3; dy <= 3; dy++) {
                int y = c.getBlockY() + dy;
                if (y < c.getWorld().getMinHeight() || y >= c.getWorld().getMaxHeight()) continue;
                Block b = c.getWorld().getBlockAt(c.getBlockX()+x, y, c.getBlockZ()+z);
                if (b.getType() == material) {
                    double d = c.distance(b.getLocation());
                    if (d < bd) { bd=d; best=b.getLocation().add(.5,.5,.5); }
                }
            }
        }
        return best;
    }

    public List<Location> findNearby(Bot bot, Material material, int radius, int limit) {
        List<Location> out = new ArrayList<>();
        if (bot == null || bot.getLocation() == null || material == null) return out;
        Location c=bot.getLocation(); int r=Math.max(1,radius);
        for (int x=-r;x<=r && out.size()<limit;x++) for(int y=-3;y<=3 && out.size()<limit;y++) for(int z=-r;z<=r && out.size()<limit;z++) {
            Block b=c.getWorld().getBlockAt(c.getBlockX()+x,c.getBlockY()+y,c.getBlockZ()+z);
            if(b.getType()==material) out.add(b.getLocation().add(.5,.5,.5));
        }
        return out;
    }

    public boolean isResource(Block block) { return block != null && block.getType() != Material.AIR; }
    public FlameBotAI getPlugin() { return plugin; }
}
