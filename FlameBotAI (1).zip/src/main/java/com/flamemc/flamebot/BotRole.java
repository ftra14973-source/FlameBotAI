package com.flamemc.flamebot;

/**
 * Defines the main AI roles available in FlameBotAI.
 */
public enum BotRole {

    /**
     * PvP focused bot.
     * Fights players, mobs and protects teammates.
     */
    PVP,

    /**
     * Resource/grinding focused bot.
     * Mines, farms and collects resources.
     */
    GRINDER,

    /**
     * Economy focused bot.
     * Farms profitable resources, especially bamboo,
     * and uses /sellgui for selling.
     */
    MONEY,

    /**
     * Rare and unpredictable AI personality.
     * Explores, observes players and behaves mysteriously.
     */
    MYSTERIOUS;

    /**
     * Returns a readable display name.
     */
    public String getDisplayName() {

        return switch (this) {

            case PVP -> "PvP";
            case GRINDER -> "Grinder";
            case MONEY -> "Money";
            case MYSTERIOUS -> "Mysterious";

        };
    }

    /**
     * Converts a text value into a BotRole.
     *
     * Example:
     * BotRole.fromString("pvp") -> PVP
     */
    public static BotRole fromString(String value) {

        if (value == null || value.isBlank()) {
            return GRINDER;
        }

        try {

            return BotRole.valueOf(
                    value.trim().toUpperCase()
            );

        } catch (IllegalArgumentException exception) {

            return GRINDER;
        }
    }

    /**
     * Checks whether this role is PvP focused.
     */
    public boolean isPvP() {
        return this == PVP;
    }

    /**
     * Checks whether this role is grinding focused.
     */
    public boolean isGrinder() {
        return this == GRINDER;
    }

    /**
     * Checks whether this role is economy focused.
     */
    public boolean isMoney() {
        return this == MONEY;
    }

    /**
     * Checks whether this role is mysterious.
     */
    public boolean isMysterious() {
        return this == MYSTERIOUS;
    }
}