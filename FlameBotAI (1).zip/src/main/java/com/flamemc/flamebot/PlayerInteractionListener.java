package com.flamemc.flamebot;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
public final class PlayerInteractionListener implements Listener {
 private final FlameBotAI plugin;
 public PlayerInteractionListener(FlameBotAI plugin){this.plugin=plugin;}
 @EventHandler public void onInteract(PlayerInteractEntityEvent e){Bot bot=plugin.getBotManager()==null?null:plugin.getBotManager().getBotByEntity(e.getRightClicked());if(bot==null)return;e.getPlayer().sendMessage("§7[§bFlameBot§7] §f"+bot.getName()+" §7| §f"+bot.getRole().getDisplayName());}
}
