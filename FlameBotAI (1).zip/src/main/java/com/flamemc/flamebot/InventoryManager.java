package com.flamemc.flamebot;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/** Inventory utilities for player-type Citizens NPCs. */
public final class InventoryManager {
    public Player getPlayer(Bot bot){return bot!=null&&bot.getEntity() instanceof Player p?p:null;}
    public int count(Bot bot, Material material){Player p=getPlayer(bot);if(p==null||material==null)return 0;int n=0;for(ItemStack s:p.getInventory().getContents())if(s!=null&&s.getType()==material)n+=s.getAmount();return n;}
    public boolean has(Bot bot, Material material,int amount){return count(bot,material)>=amount;}
    public double usage(Bot bot){Player p=getPlayer(bot);if(p==null)return 0;int used=0;for(ItemStack s:p.getInventory().getContents())if(s!=null&&!s.getType().isAir())used++;return used/(double)p.getInventory().getSize();}
    public void remember(Bot bot){if(bot!=null)bot.remember("inventory_percent",usage(bot)*100.0);}
}
