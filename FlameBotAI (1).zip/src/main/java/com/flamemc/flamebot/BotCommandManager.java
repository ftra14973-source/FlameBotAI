package com.flamemc.flamebot;

import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitTask;
import java.util.concurrent.ThreadLocalRandom;

/** Executes only explicitly allowed commands for player-type NPCs. */
public final class BotCommandManager {
    private final FlameBotAI plugin; private final CommandExecutor executor; private BukkitTask task;
    public BotCommandManager(FlameBotAI plugin){this.plugin=plugin;this.executor=new CommandExecutor(plugin);}
    public void start(){if(task!=null)return;task=Bukkit.getScheduler().runTaskTimer(plugin,()->tick(),60L,100L);}
    public void stop(){if(task!=null){task.cancel();task=null;}}
    public void reload(){}
    private void tick(){if(plugin.getBotManager()==null)return;for(Bot bot:plugin.getBotManager().getBots()){if(!bot.isSpawned()||!bot.getProfile().canUseCommands()||!bot.canUseCommand(10000)||ThreadLocalRandom.current().nextInt(100)>8)continue;if(bot.isMoneyBot()){executor.execute(bot,"sellgui");}else if(ThreadLocalRandom.current().nextBoolean()){executor.execute(bot,"bal");}else{executor.execute(bot,"spawn");}}}
    public CommandExecutor getExecutor(){return executor;}
}
