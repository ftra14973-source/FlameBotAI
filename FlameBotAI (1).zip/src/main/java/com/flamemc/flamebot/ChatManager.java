package com.flamemc.flamebot;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.scheduler.BukkitTask;
import java.util.concurrent.ThreadLocalRandom;

/** Bot chat scheduler and player conversation entry point. */
public final class ChatManager {
    private final FlameBotAI plugin; private BukkitTask task; private ConversationManager conversations;
    public ChatManager(FlameBotAI plugin){this.plugin=plugin;this.conversations=new ConversationManager(plugin);}
    public void start(){if(task!=null)return;task=Bukkit.getScheduler().runTaskTimer(plugin,()->tick(),40L,100L);}
    public void stop(){if(task!=null){task.cancel();task=null;}}
    public void reload(){}
    private void tick(){if(plugin.getBotManager()==null)return;for(Bot bot:plugin.getBotManager().getBots()){if(!bot.isSpawned()||!bot.getProfile().canChat()||!bot.canChat(8000))continue;if(ThreadLocalRandom.current().nextInt(100)<18){String msg=HinglishChat.random(bot.getRole());Bukkit.broadcastMessage("<"+bot.getName()+"> "+msg);bot.setLastMessage(msg);bot.markChat();}}}
    @EventHandler public void onChat(AsyncPlayerChatEvent e){String msg=e.getMessage().toLowerCase();for(Bot bot:plugin.getBotManager().getBots()){if(!bot.isSpawned()||bot.getLocation()==null)continue;if(bot.getLocation().getWorld().equals(e.getPlayer().getWorld())&&bot.getLocation().distance(e.getPlayer().getLocation())<=24&&(msg.contains(bot.getName().toLowerCase())||msg.equals("bot"))){Bukkit.getScheduler().runTask(plugin,()->conversations.reply(bot,e.getPlayer(),HinglishChat.random(bot.getRole())));break;}}}
    public ConversationManager getConversationManager(){return conversations;}
}
