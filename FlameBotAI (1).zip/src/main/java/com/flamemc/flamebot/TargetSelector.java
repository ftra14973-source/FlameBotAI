package com.flamemc.flamebot;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

/** Selects the best nearby target while respecting bot/friendly rules. */
public final class TargetSelector {
    private final BotManager botManager;
    private final CombatManager combat;

    public TargetSelector(BotManager botManager, CombatManager combat) {
        this.botManager = botManager;
        this.combat = combat;
    }

    public Entity select(Bot bot) {
        if (bot == null || bot.getLocation() == null) return null;
        Player player = combat.findNearestPlayer(bot);
        LivingEntity mob = combat.findNearestMob(bot);
        if (player == null) return mob;
        if (mob == null) return player;
        return distance(bot.getLocation(), player.getLocation()) <= distance(bot.getLocation(), mob.getLocation()) ? player : mob;
    }

    public Player nearestPlayer(Bot bot) { return combat.findNearestPlayer(bot); }
    public LivingEntity nearestMob(Bot bot) { return combat.findNearestMob(bot); }
    public BotManager getBotManager() { return botManager; }
    private double distance(Location a, Location b) { return a.getWorld().equals(b.getWorld()) ? a.distance(b) : Double.MAX_VALUE; }
}
