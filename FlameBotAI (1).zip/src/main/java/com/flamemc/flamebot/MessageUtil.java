package com.flamemc.flamebot;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
public final class MessageUtil {
 private MessageUtil(){}
 public static String color(String s){return ChatColor.translateAlternateColorCodes('&',s==null?"":s);}
 public static void send(CommandSender s,String m){if(s!=null)s.sendMessage(color(m));}
 public static void broadcast(String m){Bukkit.broadcastMessage(color(m));}
}
