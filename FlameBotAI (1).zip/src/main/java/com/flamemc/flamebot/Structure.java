package com.flamemc.flamebot;

import org.bukkit.Location;
import org.bukkit.Material;

/** Simple immutable structure description. */
public final class Structure {
    private final String name; private final Material material; private final int width,height,depth;
    public Structure(String name, Material material, int width, int height, int depth){this.name=name;this.material=material;this.width=width;this.height=height;this.depth=depth;}
    public String getName(){return name;} public Material getMaterial(){return material;} public int getWidth(){return width;} public int getHeight(){return height;} public int getDepth(){return depth;}
    public void build(Location origin){if(origin==null||material==null)return;for(int x=0;x<width;x++)for(int y=0;y<height;y++)for(int z=0;z<depth;z++)origin.getWorld().getBlockAt(origin.getBlockX()+x,origin.getBlockY()+y,origin.getBlockZ()+z).setType(material,false);}
}
