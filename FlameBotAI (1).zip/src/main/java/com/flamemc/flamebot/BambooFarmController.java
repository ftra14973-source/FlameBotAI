package com.flamemc.flamebot;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

/** Bamboo workflow: locate -> harvest -> collect -> sell via /sellgui only. */
public final class BambooFarmController {
    private final FlameBotAI plugin;
    private final ResourceManager resources;
    public BambooFarmController(FlameBotAI plugin) { this.plugin=plugin; this.resources=new ResourceManager(plugin); }

    public Location findBamboo(Bot bot, int radius) { return resources.findNearest(bot, Material.BAMBOO, radius); }
    public boolean harvest(Bot bot, Location bamboo) {
        if (bot==null || bamboo==null) return false;
        Block b=bamboo.getBlock(); if(b.getType()!=Material.BAMBOO && b.getType()!=Material.BAMBOO_SAPLING) return false;
        b.breakNaturally(); bot.remember("last_bamboo_harvest", System.currentTimeMillis()); bot.setState(BotState.BAMBOO_FARMING); return true;
    }
    public void tick(Bot bot) {
        if(bot==null || !bot.isMoneyBot()) return;
        Location target=findBamboo(bot,20);
        if(target==null){bot.setCurrentTask("Searching for bamboo");return;}
        if(bot.getLocation().distance(target)>3){bot.setCurrentTask("Going to bamboo"); if(plugin.getNPCManager()!=null) plugin.getNPCManager().move(bot,target); return;}
        harvest(bot,target);
        bot.setCurrentTask("Farming bamboo");
    }
    public boolean shouldSell(Bot bot) { Object v=bot==null?null:bot.recall("bamboo_amount"); return v instanceof Number n && n.intValue()>=32; }
    public void sellWithSellGui(Bot bot) { if(bot==null)return; bot.setState(BotState.SELLING); bot.setLastCommand("/sellgui"); bot.remember("sell_command","/sellgui"); bot.remember("blocked_command","/sell"); }
    public Player asPlayer(Bot bot){ return bot!=null && bot.getEntity() instanceof Player p ? p : null; }
    public ResourceManager getResources(){return resources;}
}
