package com.flamemc.flamebot;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

/**
 * Pathfinding system for FlameBotAI.
 *
 * Provides lightweight server-safe navigation for bots.
 * It checks terrain, obstacles, height differences and
 * nearby blocks before selecting movement positions.
 */
public class Pathfinding {

    private final FlameBotAI plugin;

    private static final int MAX_SEARCH_DISTANCE = 32;
    private static final int MAX_NODES = 1200;

    public Pathfinding(
            FlameBotAI plugin
    ) {

        if (plugin == null) {
            throw new IllegalArgumentException(
                    "FlameBotAI plugin cannot be null."
            );
        }

        this.plugin = plugin;
    }

    // =========================================================
    // FIND PATH
    // =========================================================

    public List<Location> findPath(
            Location start,
            Location target
    ) {

        if (!isValidLocation(start)
                || !isValidLocation(target)) {

            return Collections.emptyList();
        }

        if (!start.getWorld()
                .equals(target.getWorld())) {

            return Collections.emptyList();
        }

        /*
         * Don't calculate enormous paths.
         */
        if (horizontalDistance(
                start,
                target
        ) > MAX_SEARCH_DISTANCE) {

            target =
                    limitTargetDistance(
                            start,
                            target,
                            MAX_SEARCH_DISTANCE
                    );
        }

        Node startNode =
                new Node(
                        toGrid(start)
                );

        Node targetNode =
                new Node(
                        toGrid(target)
                );

        PriorityQueue<Node> open =
                new PriorityQueue<>(
                        Comparator.comparingDouble(
                                Node::getFScore
                        )
                );

        Map<GridPoint, Node> allNodes =
                new HashMap<>();

        Set<GridPoint> closed =
                new HashSet<>();

        startNode.gScore = 0.0;

        startNode.hScore =
                heuristic(
                        startNode.point,
                        targetNode.point
                );

        allNodes.put(
                startNode.point,
                startNode
        );

        open.add(startNode);

        int processedNodes = 0;

        while (!open.isEmpty()
                && processedNodes < MAX_NODES) {

            Node current =
                    open.poll();

            if (closed.contains(
                    current.point
            )) {
                continue;
            }

            closed.add(
                    current.point
            );

            processedNodes++;

            if (current.point.equals(
                    targetNode.point
            )) {

                return reconstructPath(
                        current,
                        start.getWorld()
                );
            }

            for (GridPoint neighbour :
                    getNeighbours(
                            current.point
                    )) {

                if (closed.contains(neighbour)) {
                    continue;
                }

                Location neighbourLocation =
                        toLocation(
                                start.getWorld(),
                                neighbour
                        );

                if (!isWalkable(
                        neighbourLocation
                )) {
                    continue;
                }

                double movementCost =
                        movementCost(
                                current.point,
                                neighbour
                        );

                double tentativeG =
                        current.gScore
                                + movementCost;

                Node neighbourNode =
                        allNodes.get(
                                neighbour
                        );

                if (neighbourNode == null) {

                    neighbourNode =
                            new Node(
                                    neighbour
                            );

                    allNodes.put(
                            neighbour,
                            neighbourNode
                    );
                }

                if (tentativeG
                        < neighbourNode.gScore) {

                    neighbourNode.parent =
                            current;

                    neighbourNode.gScore =
                            tentativeG;

                    neighbourNode.hScore =
                            heuristic(
                                    neighbour,
                                    targetNode.point
                            );

                    open.add(
                            neighbourNode
                    );
                }
            }
        }

        /*
         * No valid path found.
         */
        return Collections.emptyList();
    }

    // =========================================================
    // NEIGHBOURS
    // =========================================================

    private List<GridPoint> getNeighbours(
            GridPoint point
    ) {

        List<GridPoint> result =
                new ArrayList<>();

        /*
         * Four cardinal directions.
         */
        result.add(
                new GridPoint(
                        point.x + 1,
                        point.y,
                        point.z
                )
        );

        result.add(
                new GridPoint(
                        point.x - 1,
                        point.y,
                        point.z
                )
        );

        result.add(
                new GridPoint(
                        point.x,
                        point.y,
                        point.z + 1
                )
        );

        result.add(
                new GridPoint(
                        point.x,
                        point.y,
                        point.z - 1
                )
        );

        /*
         * Allow climbing one block.
         */
        result.add(
                new GridPoint(
                        point.x + 1,
                        point.y + 1,
                        point.z
                )
        );

        result.add(
                new GridPoint(
                        point.x - 1,
                        point.y + 1,
                        point.z
                )
        );

        result.add(
                new GridPoint(
                        point.x,
                        point.y + 1,
                        point.z + 1
                )
        );

        result.add(
                new GridPoint(
                        point.x,
                        point.y + 1,
                        point.z - 1
                )
        );

        /*
         * Allow walking down one block.
         */
        result.add(
                new GridPoint(
                        point.x + 1,
                        point.y - 1,
                        point.z
                )
        );

        result.add(
                new GridPoint(
                        point.x - 1,
                        point.y - 1,
                        point.z
                )
        );

        result.add(
                new GridPoint(
                        point.x,
                        point.y - 1,
                        point.z + 1
                )
        );

        result.add(
                new GridPoint(
                        point.x,
                        point.y - 1,
                        point.z - 1
                )
        );

        return result;
    }

    // =========================================================
    // WALKABILITY
    // =========================================================

    public boolean isWalkable(
            Location location
    ) {

        if (!isValidLocation(location)) {
            return false;
        }

        World world =
                location.getWorld();

        int x =
                location.getBlockX();

        int y =
                location.getBlockY();

        int z =
                location.getBlockZ();

        /*
         * Don't allow navigation outside world height.
         */
        if (y <= world.getMinHeight()
                || y + 2 >= world.getMaxHeight()) {

            return false;
        }

        Block feet =
                world.getBlockAt(
                        x,
                        y,
                        z
                );

        Block head =
                world.getBlockAt(
                        x,
                        y + 1,
                        z
                );

        Block ground =
                world.getBlockAt(
                        x,
                        y - 1,
                        z
                );

        /*
         * Bot needs two blocks of free space.
         */
        if (!isPassable(feet)
                || !isPassable(head)) {

            return false;
        }

        /*
         * Must have solid ground.
         */
        return isSafeGround(ground);
    }

    private boolean isPassable(
            Block block
    ) {

        if (block == null) {
            return false;
        }

        Material material =
                block.getType();

        if (material.isAir()) {
            return true;
        }

        /*
         * Basic dangerous blocks.
         */
        if (material == Material.LAVA
                || material == Material.FIRE
                || material == Material.SOUL_FIRE
                || material == Material.CACTUS) {

            return false;
        }

        return block.isPassable();
    }

    private boolean isSafeGround(
            Block block
    ) {

        if (block == null) {
            return false;
        }

        Material material =
                block.getType();

        if (material.isAir()) {
            return false;
        }

        if (material == Material.LAVA
                || material == Material.FIRE
                || material == Material.SOUL_FIRE) {

            return false;
        }

        return material.isSolid();
    }

    // =========================================================
    // RANDOM SAFE LOCATION
    // =========================================================

    public Location findRandomSafeLocation(
            Location center,
            int radius
    ) {

        if (!isValidLocation(center)) {
            return null;
        }

        if (radius <= 0) {
            radius = 8;
        }

        for (int attempt = 0;
                attempt < 40;
                attempt++) {

            int x =
                    center.getBlockX()
                            + random(
                                    -radius,
                                    radius
                            );

            int z =
                    center.getBlockZ()
                            + random(
                                    -radius,
                                    radius
                            );

            int highestY =
                    center.getWorld()
                            .getHighestBlockYAt(
                                    x,
                                    z
                            );

            Location candidate =
                    new Location(
                            center.getWorld(),
                            x + 0.5,
                            highestY + 1,
                            z + 0.5
                    );

            if (isWalkable(candidate)) {
                return candidate;
            }
        }

        return null;
    }

    // =========================================================
    // LIMIT TARGET DISTANCE
    // =========================================================

    private Location limitTargetDistance(
            Location start,
            Location target,
            int maxDistance
    ) {

        double distance =
                horizontalDistance(
                        start,
                        target
                );

        if (distance <= maxDistance) {
            return target;
        }

        double ratio =
                maxDistance / distance;

        double x =
                start.getX()
                        + (
                        target.getX()
                                - start.getX()
                ) * ratio;

        double z =
                start.getZ()
                        + (
                        target.getZ()
                                - start.getZ()
                ) * ratio;

        return new Location(
                start.getWorld(),
                x,
                target.getY(),
                z,
                target.getYaw(),
                target.getPitch()
        );
    }

    // =========================================================
    // GRID CONVERSION
    // =========================================================

    private GridPoint toGrid(
            Location location
    ) {

        return new GridPoint(
                location.getBlockX(),
                location.getBlockY(),
                location.getBlockZ()
        );
    }

    private Location toLocation(
            World world,
            GridPoint point
    ) {

        return new Location(
                world,
                point.x + 0.5,
                point.y,
                point.z + 0.5
        );
    }

    // =========================================================
    // HEURISTIC
    // =========================================================

    private double heuristic(
            GridPoint a,
            GridPoint b
    ) {

        return Math.abs(
                a.x - b.x
        )
                + Math.abs(
                a.y - b.y
        )
                + Math.abs(
                a.z - b.z
        );
    }

    // =========================================================
    // MOVEMENT COST
    // =========================================================

    private double movementCost(
            GridPoint a,
            GridPoint b
    ) {

        int vertical =
                Math.abs(
                        a.y - b.y
                );

        if (vertical > 0) {
            return 1.5;
        }

        return 1.0;
    }

    // =========================================================
    // PATH RECONSTRUCTION
    // =========================================================

    private List<Location> reconstructPath(
            Node end,
            World world
    ) {

        List<Location> path =
                new ArrayList<>();

        Node current =
                end;

        while (current != null) {

            path.add(
                    toLocation(
                            world,
                            current.point
                    )
            );

            current =
                    current.parent;
        }

        Collections.reverse(path);

        return path;
    }

    // =========================================================
    // VALIDATION
    // =========================================================

    private boolean isValidLocation(
            Location location
    ) {

        return location != null
                && location.getWorld() != null;
    }

    private double horizontalDistance(
            Location a,
            Location b
    ) {

        double dx =
                a.getX() - b.getX();

        double dz =
                a.getZ() - b.getZ();

        return Math.sqrt(
                dx * dx
                        + dz * dz
        );
    }

    private int random(
            int min,
            int max
    ) {

        if (max <= min) {
            return min;
        }

        return ThreadLocalRandomHolder.nextInt(
                min,
                max + 1
        );
    }

    // =========================================================
    // INTERNAL GRID POINT
    // =========================================================

    private static class GridPoint {

        private final int x;
        private final int y;
        private final int z;

        private GridPoint(
                int x,
                int y,
                int z
        ) {

            this.x = x;
            this.y = y;
            this.z = z;
        }

        @Override
        public boolean equals(
                Object object
        ) {

            if (this == object) {
                return true;
            }

            if (!(object instanceof GridPoint other)) {
                return false;
            }

            return x == other.x
                    && y == other.y
                    && z == other.z;
        }

        @Override
        public int hashCode() {

            int result = x;

            result =
                    31 * result + y;

            result =
                    31 * result + z;

            return result;
        }
    }

    // =========================================================
    // INTERNAL NODE
    // =========================================================

    private static class Node {

        private final GridPoint point;

        private Node parent;

        private double gScore =
                Double.POSITIVE_INFINITY;

        private double hScore =
                Double.POSITIVE_INFINITY;

        private Node(
                GridPoint point
        ) {

            this.point = point;
        }

        private double getFScore() {

            return gScore + hScore;
        }
    }

    // =========================================================
    // RANDOM HOLDER
    // =========================================================

    private static class ThreadLocalRandomHolder {

        private static int nextInt(
                int min,
                int max
        ) {

            return java.util.concurrent
                    .ThreadLocalRandom
                    .current()
                    .nextInt(
                            min,
                            max
                    );
        }
    }
    // =========================================================
    // PUBLIC PATH HELPERS
    // =========================================================

    /**
     * Checks whether a direct route between two locations
     * is reasonably safe.
     */
    public boolean hasDirectPath(
            Location start,
            Location target
    ) {

        if (!isValidLocation(start)
                || !isValidLocation(target)) {

            return false;
        }

        if (!start.getWorld()
                .equals(target.getWorld())) {

            return false;
        }

        double distance =
                horizontalDistance(
                        start,
                        target
                );

        if (distance > MAX_SEARCH_DISTANCE) {
            return false;
        }

        int steps =
                Math.max(
                        1,
                        (int) Math.ceil(distance)
                );

        for (int i = 0; i <= steps; i++) {

            double progress =
                    (double) i / steps;

            double x =
                    start.getX()
                            + (
                            target.getX()
                                    - start.getX()
                    ) * progress;

            double z =
                    start.getZ()
                            + (
                            target.getZ()
                                    - start.getZ()
                    ) * progress;

            int blockX =
                    (int) Math.floor(x);

            int blockZ =
                    (int) Math.floor(z);

            int groundY =
                    start.getWorld()
                            .getHighestBlockYAt(
                                    blockX,
                                    blockZ
                            );

            Location check =
                    new Location(
                            start.getWorld(),
                            blockX + 0.5,
                            groundY + 1,
                            blockZ + 0.5
                    );

            if (!isWalkable(check)) {
                return false;
            }
        }

        return true;
    }

    // =========================================================
    // GET NEXT STEP
    // =========================================================

    /**
     * Returns the first useful movement position
     * from a calculated path.
     */
    public Location getNextStep(
            Location start,
            Location target
    ) {

        List<Location> path =
                findPath(
                        start,
                        target
                );

        if (path.isEmpty()) {
            return null;
        }

        /*
         * First node is normally the current position.
         * Find the first different position.
         */
        for (Location location : path) {

            if (location == null) {
                continue;
            }

            if (horizontalDistance(
                    start,
                    location
            ) > 0.8) {

                return location;
            }
        }

        return null;
    }

    // =========================================================
    // RANDOM EXPLORATION TARGET
    // =========================================================

    public Location getExplorationTarget(
            Location current,
            int radius
    ) {

        if (!isValidLocation(current)) {
            return null;
        }

        if (radius <= 0) {
            radius = 16;
        }

        /*
         * Try multiple random destinations.
         */
        for (int attempt = 0;
                attempt < 20;
                attempt++) {

            Location candidate =
                    findRandomSafeLocation(
                            current,
                            radius
                    );

            if (candidate == null) {
                continue;
            }

            /*
             * Avoid selecting a location too close
             * to the bot.
             */
            if (horizontalDistance(
                    current,
                    candidate
            ) < 5.0) {

                continue;
            }

            return candidate;
        }

        return null;
    }

    // =========================================================
    // SAFE GROUND LOCATION
    // =========================================================

    public Location findSafeGround(
            Location location
    ) {

        if (!isValidLocation(location)) {
            return null;
        }

        World world =
                location.getWorld();

        int x =
                location.getBlockX();

        int z =
                location.getBlockZ();

        int highest =
                world.getHighestBlockYAt(
                        x,
                        z
                );

        /*
         * Check several blocks around the
         * highest point in case it is unsafe.
         */
        for (int offset = 0;
                offset <= 6;
                offset++) {

            int y =
                    highest - offset;

            if (y <= world.getMinHeight()) {
                break;
            }

            Location candidate =
                    new Location(
                            world,
                            x + 0.5,
                            y + 1,
                            z + 0.5
                    );

            if (isWalkable(candidate)) {
                return candidate;
            }
        }

        return null;
    }

    // =========================================================
    // WATER / LAVA SAFETY
    // =========================================================

    public boolean isDangerous(
            Location location
    ) {

        if (!isValidLocation(location)) {
            return true;
        }

        World world =
                location.getWorld();

        int x =
                location.getBlockX();

        int y =
                location.getBlockY();

        int z =
                location.getBlockZ();

        Block feet =
                world.getBlockAt(
                        x,
                        y,
                        z
                );

        Block ground =
                world.getBlockAt(
                        x,
                        y - 1,
                        z
                );

        return isDangerousBlock(feet)
                || isDangerousBlock(ground);
    }

    private boolean isDangerousBlock(
            Block block
    ) {

        if (block == null) {
            return true;
        }

        Material material =
                block.getType();

        return material == Material.LAVA
                || material == Material.FIRE
                || material == Material.SOUL_FIRE
                || material == Material.CACTUS
                || material == Material.MAGMA_BLOCK
                || material == Material.CAMPFIRE
                || material == Material.SOUL_CAMPFIRE;
    }

    // =========================================================
    // HEIGHT CHECK
    // =========================================================

    public boolean isReasonableHeight(
            Location from,
            Location to
    ) {

        if (!isValidLocation(from)
                || !isValidLocation(to)) {

            return false;
        }

        return Math.abs(
                from.getY()
                        - to.getY()
        ) <= 2.0;
    }

    // =========================================================
    // PATH LENGTH
    // =========================================================

    public double getPathLength(
            List<Location> path
    ) {

        if (path == null
                || path.size() < 2) {

            return 0.0;
        }

        double total = 0.0;

        for (int i = 1;
                i < path.size();
                i++) {

            Location previous =
                    path.get(i - 1);

            Location current =
                    path.get(i);

            if (previous == null
                    || current == null) {

                continue;
            }

            if (!previous.getWorld()
                    .equals(current.getWorld())) {

                continue;
            }

            total +=
                    previous.distance(
                            current
                    );
        }

        return total;
    }

    // =========================================================
    // PATH VALIDATION
    // =========================================================

    public boolean isPathValid(
            List<Location> path
    ) {

        if (path == null
                || path.isEmpty()) {

            return false;
        }

        for (Location location : path) {

            if (!isValidLocation(location)) {
                return false;
            }

            if (isDangerous(location)) {
                return false;
            }

            if (!isWalkable(location)) {
                return false;
            }
        }

        return true;
    }

    // =========================================================
    // FIND NEAREST SAFE POSITION
    // =========================================================

    public Location findNearestSafePosition(
            Location center,
            int radius
    ) {

        if (!isValidLocation(center)) {
            return null;
        }

        if (radius <= 0) {
            radius = 8;
        }

        Location best = null;

        double bestDistance =
                Double.MAX_VALUE;

        for (int x = -radius;
                x <= radius;
                x++) {

            for (int z = -radius;
                    z <= radius;
                    z++) {

                if (x == 0 && z == 0) {
                    continue;
                }

                Location candidate =
                        center.clone().add(
                                x,
                                0,
                                z
                        );

                Location safe =
                        findSafeGround(
                                candidate
                        );

                if (safe == null) {
                    continue;
                }

                double distance =
                        horizontalDistance(
                                center,
                                safe
                        );

                if (distance < bestDistance) {

                    bestDistance =
                            distance;

                    best = safe;
                }
            }
        }

        return best;
    }

    // =========================================================
    // PATH DEBUG
    // =========================================================

    public String getPathInfo(
            Location start,
            Location target
    ) {

        if (!isValidLocation(start)
                || !isValidLocation(target)) {

            return "Invalid location";
        }

        List<Location> path =
                findPath(
                        start,
                        target
                );

        if (path.isEmpty()) {

            return "No path found";
        }

        return "Path found | Steps="
                + path.size()
                + " | Length="
                + String.format(
                        "%.1f",
                        getPathLength(path)
                );
    }

    // =========================================================
    // CONSTANT GETTERS
    // =========================================================

    public int getMaxSearchDistance() {
        return MAX_SEARCH_DISTANCE;
    }

    public int getMaxNodes() {
        return MAX_NODES;
    }

    public FlameBotAI getPlugin() {
        return plugin;
    }

    // =========================================================
    // END OF PATHFINDING
    // =========================================================
}