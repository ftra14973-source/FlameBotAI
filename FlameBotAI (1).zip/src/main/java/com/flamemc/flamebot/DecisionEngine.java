package com.flamemc.flamebot;

import org.bukkit.entity.Player;

import java.util.concurrent.ThreadLocalRandom;

/**
 * DecisionEngine
 *
 * Decides what a bot should prioritize based on:
 * - Bot role
 * - Current state
 * - Nearby players
 * - Health
 * - Food
 * - Inventory pressure
 * - Social activity
 * - Randomness
 *
 * This class does NOT directly perform actions.
 * It only makes decisions for the AI system.
 */
public class DecisionEngine {

    private final FlameBotAI plugin;
    private final BotManager botManager;

    public DecisionEngine(
            FlameBotAI plugin,
            BotManager botManager
    ) {

        if (plugin == null) {
            throw new IllegalArgumentException(
                    "FlameBotAI plugin cannot be null."
            );
        }

        if (botManager == null) {
            throw new IllegalArgumentException(
                    "BotManager cannot be null."
            );
        }

        this.plugin = plugin;
        this.botManager = botManager;
    }

    // =========================================================
    // MAIN DECISION
    // =========================================================

    public BotState decide(Bot bot) {

        if (bot == null) {
            return BotState.IDLE;
        }

        if (!bot.isSpawned()
                || !bot.isAlive()
                || !bot.isOnline()) {

            return BotState.IDLE;
        }

        /*
         * Survival has the highest priority.
         */
        if (needsEmergencyAction(bot)) {
            return BotState.ESCAPING;
        }

        /*
         * Active combat should not be interrupted easily.
         */
        if (isCurrentlyInCombat(bot)) {

            if (hasValidCombatTarget(bot)) {
                return BotState.PVP_COMBAT;
            }

            return BotState.MOB_COMBAT;
        }

        /*
         * Role-specific decisions.
         */
        return switch (bot.getRole()) {

            case PVP ->
                    decidePvP(bot);

            case GRINDER ->
                    decideGrinder(bot);

            case MONEY ->
                    decideMoney(bot);

            case MYSTERIOUS ->
                    decideMysterious(bot);
        };
    }

    // =========================================================
    // PVP DECISION
    // =========================================================

    private BotState decidePvP(Bot bot) {

        Player player =
                botManager.findNearestPlayer(
                        bot,
                        32.0
                );

        /*
         * Nearby player = possible PvP.
         */
        if (player != null) {

            if (isGoodPvPOpportunity(bot, player)) {
                return BotState.PVP_COMBAT;
            }

            /*
             * Sometimes PvP bots observe before engaging.
             */
            if (randomChance(20)) {
                return BotState.OBSERVING;
            }
        }

        /*
         * Healthy PvP bots can train against mobs.
         */
        if (randomChance(25)) {
            return BotState.MOB_COMBAT;
        }

        /*
         * PvP bots also explore to find players.
         */
        if (randomChance(35)) {
            return BotState.EXPLORING;
        }

        /*
         * Occasionally return to base.
         */
        if (randomChance(10)) {
            return BotState.RETURNING_HOME;
        }

        return BotState.IDLE;
    }

    // =========================================================
    // GRINDER DECISION
    // =========================================================

    private BotState decideGrinder(Bot bot) {

        /*
         * Inventory management comes before
         * continuing a long resource session.
         */
        if (isInventoryPressureHigh(bot)) {
            return BotState.MANAGING_INVENTORY;
        }

        /*
         * Main grinder activities.
         */
        int roll =
                random(
                        0,
                        100
                );

        if (roll < 40) {
            return BotState.MINING;
        }

        if (roll < 65) {
            return BotState.FARMING;
        }

        if (roll < 78) {
            return BotState.EXPLORING;
        }

        if (roll < 88) {
            return BotState.BUILDING;
        }

        if (roll < 94) {
            return BotState.STORING_ITEMS;
        }

        return BotState.IDLE;
    }

    // =========================================================
    // MONEY BOT DECISION
    // =========================================================

    private BotState decideMoney(Bot bot) {

        /*
         * MONEY bots have a strict economy loop:
         *
         * Bamboo
         *   ↓
         * Inventory
         *   ↓
         * /sellgui
         *   ↓
         * /bal
         *   ↓
         * Bamboo again
         */

        if (hasEnoughBambooToSell(bot)) {
            return BotState.SELLING;
        }

        if (isInventoryPressureHigh(bot)) {
            return BotState.MANAGING_INVENTORY;
        }

        /*
         * Bamboo is the primary resource.
         */
        int roll =
                random(
                        0,
                        100
                );

        if (roll < 70) {
            return BotState.BAMBOO_FARMING;
        }

        if (roll < 80) {
            return BotState.EXPLORING;
        }

        if (roll < 88) {
            return BotState.BUILDING;
        }

        if (roll < 94) {
            return BotState.CHECKING_BALANCE;
        }

        return BotState.IDLE;
    }

    // =========================================================
    // MYSTERIOUS DECISION
    // =========================================================

    private BotState decideMysterious(Bot bot) {

        /*
         * UNKNOWN behaves differently from other bots.
         *
         * Low social activity.
         * Unpredictable movement.
         * Long observation periods.
         * Hidden objective.
         */

        int roll =
                random(
                        0,
                        100
                );

        if (roll < 25) {
            return BotState.OBSERVING;
        }

        if (roll < 40) {
            return BotState.EXPLORING;
        }

        if (roll < 52) {
            return BotState.MYSTERIOUS_ACTIVITY;
        }

        if (roll < 62) {
            return BotState.MINING;
        }

        if (roll < 70) {
            return BotState.BUILDING;
        }

        if (roll < 76) {
            return BotState.FOLLOWING_PLAYER;
        }

        /*
         * UNKNOWN spends a lot of time doing nothing visible.
         */
        return BotState.IDLE;
    }

    // =========================================================
    // EMERGENCY DECISION
    // =========================================================

    private boolean needsEmergencyAction(
            Bot bot
    ) {

        /*
         * Very low health.
         */
        if (bot.getHealth() <= 4.0) {
            return true;
        }

        /*
         * Very low food.
         */
        if (bot.getFoodLevel() <= 5) {
            return true;
        }

        /*
         * Explicit combat escape state.
         */
        return bot.getState()
                == BotState.ESCAPING;
    }

    // =========================================================
    // COMBAT CHECKS
    // =========================================================

    private boolean isCurrentlyInCombat(
            Bot bot
    ) {

        BotState state =
                bot.getState();

        if (state == null) {
            return false;
        }

        return state == BotState.PVP_COMBAT
                || state == BotState.MOB_COMBAT
                || state == BotState.DEFENDING;
    }

    private boolean hasValidCombatTarget(
            Bot bot
    ) {

        return bot.getTargetId() != null;
    }

    private boolean isGoodPvPOpportunity(
            Bot bot,
            Player player
    ) {

        if (player == null
                || !player.isOnline()
                || player.isDead()) {

            return false;
        }

        /*
         * Don't attack players when bot is
         * critically weak.
         */
        if (bot.getHealth() <= 8.0) {
            return false;
        }

        /*
         * Bot bravery affects engagement.
         */
        int bravery =
                bot.getProfile().getBravery();

        int aggression =
                bot.getProfile().getAggression();

        int chance =
                (bravery + aggression) / 2;

        /*
         * Small randomness keeps behaviour natural.
         */
        return randomChance(chance);
    }

    // =========================================================
    // INVENTORY
    // =========================================================

    private boolean isInventoryPressureHigh(
            Bot bot
    ) {

        /*
         * Actual inventory calculation will be handled
         * by InventoryManager.
         *
         * For now use the bot's remembered inventory
         * percentage if available.
         */

        Object value =
                bot.getMemory(
                        "inventory_percent"
                );

        if (value instanceof Number number) {

            return number.doubleValue() >= 85.0;
        }

        return false;
    }

    // =========================================================
    // BAMBOO CHECK
    // =========================================================

    private boolean hasEnoughBambooToSell(
            Bot bot
    ) {

        /*
         * MONEY bot remembers the amount of bamboo
         * currently available.
         */

        Object value =
                bot.getMemory(
                        "bamboo_amount"
                );

        if (value instanceof Number number) {

            return number.intValue() >= 32;
        }

        return false;
    }

    // =========================================================
    // RANDOM
    // =========================================================

    private boolean randomChance(
            int percentage
    ) {

        if (percentage <= 0) {
            return false;
        }

        if (percentage >= 100) {
            return true;
        }

        return ThreadLocalRandom.current()
                .nextInt(100)
                < percentage;
    }

    private int random(
            int min,
            int max
    ) {

        if (max <= min) {
            return min;
        }

        return ThreadLocalRandom.current()
                .nextInt(
                        min,
                        max + 1
                );
    }

    // =========================================================
    // GETTERS
    // =========================================================

    public FlameBotAI getPlugin() {
        return plugin;
    }

    public BotManager getBotManager() {
        return botManager;
    }
    // =========================================================
    // PRIORITY SYSTEM
    // =========================================================

    /**
     * Returns a numeric priority for the current situation.
     *
     * Higher number = more important.
     */
    public int getPriority(Bot bot) {

        if (bot == null) {
            return 0;
        }

        /*
         * Survival always comes first.
         */
        if (bot.getHealth() <= 4.0
                || bot.getFoodLevel() <= 5) {

            return 100;
        }

        /*
         * Active PvP is extremely important.
         */
        if (bot.getState()
                == BotState.PVP_COMBAT) {

            return 95;
        }

        /*
         * Inventory pressure.
         */
        if (isInventoryPressureHigh(bot)) {
            return 85;
        }

        /*
         * Money bots selling valuable bamboo.
         */
        if (bot.getRole().isMoney()
                && hasEnoughBambooToSell(bot)) {

            return 90;
        }

        /*
         * Building / farming / mining.
         */
        if (bot.getState() == BotState.BUILDING
                || bot.getState() == BotState.MINING
                || bot.getState() == BotState.FARMING
                || bot.getState()
                == BotState.BAMBOO_FARMING) {

            return 70;
        }

        /*
         * Social activity.
         */
        if (bot.getState() == BotState.TALKING
                || bot.getState()
                == BotState.BOT_CONVERSATION) {

            return 45;
        }

        /*
         * Exploration.
         */
        if (bot.getState()
                == BotState.EXPLORING) {

            return 35;
        }

        return 20;
    }

    // =========================================================
    // COMMAND DECISION
    // =========================================================

    /**
     * Returns the best command for a situation.
     *
     * This method only returns commands that are allowed
     * by FlameBotAI's command system.
     */
    public String chooseCommand(Bot bot) {

        if (bot == null) {
            return null;
        }

        /*
         * MONEY BOT:
         *
         * Never return /sell.
         * Always use /sellgui.
         */
        if (bot.getRole().isMoney()) {

            if (hasEnoughBambooToSell(bot)) {

                return "/sellgui";
            }

            /*
             * Check balance occasionally.
             */
            if (randomChance(15)) {

                return "/bal";
            }
        }

        /*
         * Return home when the bot has enough resources.
         */
        if (randomChance(8)) {

            return "/home";
        }

        /*
         * Explore when the bot has no useful destination.
         */
        if (randomChance(12)) {

            return "/rtp";
        }

        /*
         * Social bots may message players.
         */
        if (bot.getProfile().canChat()
                && randomChance(8)) {

            return "/msg";
        }

        return null;
    }

    // =========================================================
    // RESOURCE DECISION
    // =========================================================

    public String chooseResource(Bot bot) {

        if (bot == null) {
            return null;
        }

        if (bot.getRole().isMoney()) {

            return "BAMBOO";
        }

        if (bot.getRole().isGrinder()) {

            int roll =
                    random(
                            0,
                            100
                    );

            if (roll < 35) {
                return "DIAMOND";
            }

            if (roll < 60) {
                return "IRON";
            }

            if (roll < 75) {
                return "COAL";
            }

            if (roll < 90) {
                return "WOOD";
            }

            return "CROPS";
        }

        if (bot.getRole().isPvP()) {

            return "DIAMOND";
        }

        return "UNKNOWN";
    }

    // =========================================================
    // SOCIAL DECISION
    // =========================================================

    public boolean shouldTalk(
            Bot bot,
            Player player
    ) {

        if (bot == null
                || player == null) {

            return false;
        }

        if (!bot.getProfile().canChat()) {
            return false;
        }

        if (!player.isOnline()
                || player.isDead()) {

            return false;
        }

        int socialLevel =
                bot.getProfile()
                        .getSocialLevel();

        /*
         * UNKNOWN rarely talks.
         */
        if (bot.getRole().isMysterious()) {

            return socialLevel >= 10
                    && randomChance(8);
        }

        /*
         * Normal bots.
         */
        return randomChance(
                Math.max(
                        5,
                        socialLevel
                )
        );
    }

    // =========================================================
    // PLAYER FOLLOW DECISION
    // =========================================================

    public boolean shouldFollowPlayer(
            Bot bot,
            Player player
    ) {

        if (bot == null
                || player == null) {

            return false;
        }

        if (!player.isOnline()
                || player.isDead()) {

            return false;
        }

        /*
         * UNKNOWN can occasionally follow a player
         * to create mysterious behaviour.
         */
        if (bot.getRole().isMysterious()) {

            return randomChance(6);
        }

        /*
         * Friendly bots are more likely to follow.
         */
        int friendliness =
                bot.getProfile()
                        .getFriendliness();

        return randomChance(
                Math.max(
                        5,
                        friendliness / 2
                )
        );
    }

    // =========================================================
    // BOT-TO-BOT DECISION
    // =========================================================

    public boolean shouldTalkToBot(
            Bot bot,
            Bot other
    ) {

        if (bot == null
                || other == null
                || bot == other) {

            return false;
        }

        if (!bot.isSpawned()
                || !other.isSpawned()) {

            return false;
        }

        if (!bot.getProfile().canChat()) {
            return false;
        }

        /*
         * UNKNOWN remains low-frequency.
         */
        if (bot.getRole().isMysterious()) {

            return randomChance(5);
        }

        return randomChance(
                Math.max(
                        10,
                        bot.getProfile()
                                .getSocialLevel()
                                / 2
                )
        );
    }

    // =========================================================
    // BUILD DECISION
    // =========================================================

    public boolean shouldBuild(
            Bot bot
    ) {

        if (bot == null) {
            return false;
        }

        if (!bot.getProfile().canBuild()) {
            return false;
        }

        int workPriority =
                bot.getProfile()
                        .getWorkPriority();

        if (bot.getRole().isMoney()) {

            return randomChance(25);
        }

        if (bot.getRole().isGrinder()) {

            return randomChance(
                    Math.max(
                            30,
                            workPriority / 2
                    )
            );
        }

        if (bot.getRole().isPvP()) {

            return randomChance(30);
        }

        /*
         * UNKNOWN builds rarely.
         */
        return randomChance(12);
    }

    // =========================================================
    // COMBAT DECISION
    // =========================================================

    public boolean shouldFight(
            Bot bot,
            Player player
    ) {

        if (bot == null
                || player == null) {

            return false;
        }

        if (!bot.getProfile().canFight()) {
            return false;
        }

        if (!player.isOnline()
                || player.isDead()) {

            return false;
        }

        /*
         * Don't fight while critically weak.
         */
        if (bot.getHealth() <= 8.0) {
            return false;
        }

        int aggression =
                bot.getProfile()
                        .getAggression();

        int bravery =
                bot.getProfile()
                        .getBravery();

        int chance =
                (aggression + bravery) / 2;

        /*
         * PvP bots get a major boost.
         */
        if (bot.getRole().isPvP()) {

            chance += 20;
        }

        /*
         * Mysterious bot rarely initiates fights.
         */
        if (bot.getRole().isMysterious()) {

            chance /= 4;
        }

        return randomChance(
                Math.min(
                        100,
                        chance
                )
        );
    }

    // =========================================================
    // ESCAPE DECISION
    // =========================================================

    public boolean shouldEscape(
            Bot bot
    ) {

        if (bot == null) {
            return false;
        }

        /*
         * Critical health.
         */
        if (bot.getHealth() <= 4.0) {
            return true;
        }

        /*
         * Very low food.
         */
        if (bot.getFoodLevel() <= 5) {
            return true;
        }

        /*
         * Brave PvP bots have a slightly lower
         * chance of escaping.
         */
        if (bot.getRole().isPvP()) {

            return bot.getHealth() <= 2.0;
        }

        return false;
    }

    // =========================================================
    // EXPLORATION DECISION
    // =========================================================

    public boolean shouldExplore(
            Bot bot
    ) {

        if (bot == null) {
            return false;
        }

        if (bot.getRole().isMysterious()) {

            return randomChance(40);
        }

        if (bot.getRole().isPvP()) {

            /*
             * PvP bots explore to find players.
             */
            return randomChance(45);
        }

        if (bot.getRole().isGrinder()) {

            return randomChance(25);
        }

        if (bot.getRole().isMoney()) {

            return randomChance(20);
        }

        return randomChance(30);
    }

    // =========================================================
    // HOME DECISION
    // =========================================================

    public boolean shouldReturnHome(
            Bot bot
    ) {

        if (bot == null) {
            return false;
        }

        /*
         * Inventory pressure should encourage
         * returning to base.
         */
        if (isInventoryPressureHigh(bot)) {
            return true;
        }

        /*
         * Low health / food.
         */
        if (bot.getHealth() <= 8.0
                || bot.getFoodLevel() <= 8) {

            return true;
        }

        /*
         * Random natural behaviour.
         */
        return randomChance(8);
    }

    // =========================================================
    // SELL DECISION
    // =========================================================

    public boolean shouldSell(
            Bot bot
    ) {

        if (bot == null) {
            return false;
        }

        /*
         * ONLY MONEY bots sell bamboo.
         */
        if (!bot.getRole().isMoney()) {
            return false;
        }

        /*
         * Explicitly require enough bamboo.
         */
        if (!hasEnoughBambooToSell(bot)) {
            return false;
        }

        /*
         * Money bot's preferred method.
         */
        bot.remember(
                "sell_method",
                "/sellgui"
        );

        /*
         * Never allow /sell.
         */
        bot.remember(
                "forbidden_command",
                "/sell"
        );

        return true;
    }

    // =========================================================
    // THINKING DELAY
    // =========================================================

    public long getDecisionDelay(
            Bot bot
    ) {

        if (bot == null) {
            return 40L;
        }

        /*
         * Higher intelligence = slightly faster decisions.
         */
        int intelligence =
                bot.getProfile()
                        .getIntelligence();

        long base =
                30L;

        long reduction =
                intelligence / 4L;

        long delay =
                base - reduction;

        /*
         * Prevent extremely fast decisions.
         */
        return Math.max(
                10L,
                delay
        );
    }

    // =========================================================
    // RANDOM UTILITY
    // =========================================================

    private boolean randomChance(
            int percentage
    ) {

        if (percentage <= 0) {
            return false;
        }

        if (percentage >= 100) {
            return true;
        }

        return ThreadLocalRandom.current()
                .nextInt(100)
                < percentage;
    }

    private int random(
            int min,
            int max
    ) {

        if (max <= min) {
            return min;
        }

        return ThreadLocalRandom.current()
                .nextInt(
                        min,
                        max + 1
                );
    }

    // =========================================================
    // FINAL HELPERS
    // =========================================================

    public boolean isHighPriority(
            Bot bot
    ) {

        return getPriority(bot) >= 80;
    }

    public boolean isCritical(
            Bot bot
    ) {

        if (bot == null) {
            return false;
        }

        return bot.getHealth() <= 4.0
                || bot.getFoodLevel() <= 5;
    }

    public String getDecisionSummary(
            Bot bot
    ) {

        if (bot == null) {
            return "No bot";
        }

        BotState decision =
                decide(bot);

        int priority =
                getPriority(bot);

        String resource =
                chooseResource(bot);

        return "Bot="
                + bot.getName()
                + " | Role="
                + bot.getRole()
                + " | Current="
                + bot.getState()
                + " | Decision="
                + decision
                + " | Priority="
                + priority
                + " | Resource="
                + resource;
    }
}