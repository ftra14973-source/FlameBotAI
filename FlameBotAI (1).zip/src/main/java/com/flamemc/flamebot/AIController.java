package com.flamemc.flamebot;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Collection;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Main AI brain/controller for FlameBotAI.
 *
 * Handles high-level decisions for all bots.
 * Actual movement, combat, farming, building and commands
 * are delegated to their respective controllers.
 */
public class AIController {

    private final FlameBotAI plugin;
    private final BotManager botManager;

    private BukkitTask aiTask;
    private final PvPController pvpController;
    private final GrinderController grinderController;
    private final BambooFarmController bambooFarmController;
    private final BuildManager buildManager;
    private final InventoryManager inventoryManager;

    private boolean running = false;

    /*
     * 20 ticks = 1 second.
     * Bots think every 2 seconds by default.
     */
    private long thinkInterval = 40L;

    public AIController(FlameBotAI plugin) {
        this(plugin, plugin.getBotManager());
    }

    public AIController(
            FlameBotAI plugin,
            BotManager botManager
    ) {

        if (plugin == null) {
            throw new IllegalArgumentException(
                    "FlameBotAI plugin cannot be null."
            );
        }

        if (botManager == null) {
            throw new IllegalArgumentException(
                    "BotManager cannot be null."
            );
        }

        this.plugin = plugin;
        this.botManager = botManager;
        this.pvpController = new PvPController(plugin);
        this.grinderController = new GrinderController(plugin);
        this.bambooFarmController = new BambooFarmController(plugin);
        this.buildManager = new BuildManager(plugin);
        this.inventoryManager = new InventoryManager();
    }

    // =========================================================
    // START
    // =========================================================

    public void start() {

        if (running) {
            return;
        }

        running = true;

        aiTask = Bukkit.getScheduler().runTaskTimer(
                plugin,
                this::thinkAllBots,
                40L,
                thinkInterval
        );

        plugin.getLogger().info(
                "AIController started."
        );
    }

    // =========================================================
    // SHUTDOWN
    // =========================================================

    public void shutdown() {

        running = false;

        if (aiTask != null) {
            aiTask.cancel();
            aiTask = null;
        }

        plugin.getLogger().info(
                "AIController shut down."
        );
    }

    // =========================================================
    // MAIN AI LOOP
    // =========================================================

    private void thinkAllBots() {

        if (!running) {
            return;
        }

        Collection<Bot> bots =
                botManager.getBots();

        for (Bot bot : bots) {

            try {

                think(bot);

            } catch (Exception exception) {

                plugin.getLogger().warning(
                        "AI error for "
                                + bot.getName()
                                + ": "
                                + exception.getMessage()
                );
            }
        }
    }

    // =========================================================
    // SINGLE BOT THINK
    // =========================================================

    public void think(Bot bot) {

        if (bot == null) {
            return;
        }

        if (!bot.isSpawned()
                || !bot.isOnline()
                || !bot.isAlive()) {

            return;
        }

        if (bot.getEntity() == null
                || !bot.getEntity().isValid()) {

            return;
        }

        /*
         * Keep location synchronized with entity.
         */
        bot.setLocation(
                bot.getEntity().getLocation()
        );

        /*
         * Don't constantly interrupt active tasks.
         */
        if (isBusy(bot)) {

            handleBusyBot(bot);

            return;
        }

        /*
         * Small random thinking behaviour.
         */
        if (randomChance(12)) {

            bot.setState(
                    BotState.THINKING
            );
        }

        BotState nextState =
                chooseNextState(bot);

        executeState(
                bot,
                nextState
        );
    }

    // =========================================================
    // STATE DECISION
    // =========================================================

    private BotState chooseNextState(
            Bot bot
    ) {

        BotRole role =
                bot.getRole();

        if (role == null) {

            return BotState.EXPLORING;
        }

        /*
         * UNKNOWN has a special AI personality.
         */
        if (role.isMysterious()) {

            return chooseMysteriousState(bot);
        }

        // -----------------------------------------------------
        // PVP BOTS
        // -----------------------------------------------------

        if (role.isPvP()) {

            Player nearbyPlayer =
                    botManager.findNearestPlayer(
                            bot,
                            32.0
                    );

            /*
             * If a player is nearby, PvP bots have
             * a high chance of engaging.
             */
            if (nearbyPlayer != null
                    && randomChance(65)) {

                return BotState.PVP_COMBAT;
            }

            /*
             * Sometimes explore instead of fighting.
             */
            if (randomChance(20)) {

                return BotState.EXPLORING;
            }

            /*
             * Otherwise fight mobs / train.
             */
            return BotState.MOB_COMBAT;
        }

        // -----------------------------------------------------
        // GRINDER BOTS
        // -----------------------------------------------------

        if (role.isGrinder()) {

            int roll =
                    random(
                            0,
                            100
                    );

            if (roll < 45) {

                return BotState.MINING;
            }

            if (roll < 70) {

                return BotState.FARMING;
            }

            if (roll < 85) {

                return BotState.EXPLORING;
            }

            if (roll < 94) {

                return BotState.BUILDING;
            }

            return BotState.MANAGING_INVENTORY;
        }

        // -----------------------------------------------------
        // MONEY BOTS
        // -----------------------------------------------------

        if (role.isMoney()) {

            int roll =
                    random(
                            0,
                            100
                    );

            /*
             * Bamboo is the main money-bot activity.
             */
            if (roll < 60) {

                return BotState.BAMBOO_FARMING;
            }

            /*
             * Check inventory before selling.
             */
            if (roll < 72) {

                return BotState.MANAGING_INVENTORY;
            }

            /*
             * Selling is handled through /sellgui only.
             */
            if (roll < 84) {

                return BotState.SELLING;
            }

            /*
             * Balance checking.
             */
            if (roll < 92) {

                return BotState.CHECKING_BALANCE;
            }

            return BotState.EXPLORING;
        }

        return BotState.EXPLORING;
    }

    // =========================================================
    // MYSTERIOUS BOT AI
    // =========================================================

    private BotState chooseMysteriousState(
            Bot bot
    ) {

        int roll =
                random(
                        0,
                        100
                );

        /*
         * UNKNOWN should not constantly move or talk.
         */

        if (roll < 20) {

            return BotState.OBSERVING;
        }

        if (roll < 35) {

            return BotState.EXPLORING;
        }

        if (roll < 48) {

            return BotState.MYSTERIOUS_ACTIVITY;
        }

        if (roll < 58) {

            return BotState.MINING;
        }

        if (roll < 68) {

            return BotState.BUILDING;
        }

        if (roll < 76) {

            return BotState.FOLLOWING_PLAYER;
        }

        /*
         * Mostly stays quiet.
         */
        return BotState.IDLE;
    }

    // =========================================================
    // STATE EXECUTION
    // =========================================================

    private void executeState(
            Bot bot,
            BotState state
    ) {

        if (state == null) {

            state =
                    BotState.IDLE;
        }

        bot.setState(state);

        switch (state) {

            case IDLE -> idle(bot);

            case EXPLORING ->
                    explore(bot);

            case TRAVELLING ->
                    travel(bot);

            case SEARCHING_RESOURCE ->
                    searchResource(bot);

            case MINING ->
                    mine(bot);

            case FARMING ->
                    farm(bot);

            case BAMBOO_FARMING ->
                    bambooFarm(bot);

            case PVP_COMBAT ->
                    pvp(bot);

            case MOB_COMBAT ->
                    mobCombat(bot);

            case COLLECTING_LOOT ->
                    collectLoot(bot);

            case MANAGING_INVENTORY ->
                    manageInventory(bot);

            case RETURNING_HOME ->
                    returnHome(bot);

            case AT_BASE ->
                    atBase(bot);

            case BUILDING ->
                    build(bot);

            case REPAIRING ->
                    repair(bot);

            case STORING_ITEMS ->
                    storeItems(bot);

            case SELLING ->
                    sell(bot);

            case CHECKING_BALANCE ->
                    checkBalance(bot);

            case USING_COMMAND ->
                    useCommand(bot);

            case TALKING ->
                    talk(bot);

            case BOT_CONVERSATION ->
                    botConversation(bot);

            case FOLLOWING_PLAYER ->
                    followPlayer(bot);

            case FOLLOWING_BOT ->
                    followBot(bot);

            case DEFENDING ->
                    defend(bot);

            case OBSERVING ->
                    observe(bot);

            case MYSTERIOUS_ACTIVITY ->
                    mysteriousActivity(bot);

            case THINKING ->
                    bot.setState(
                            BotState.IDLE
                    );

            default ->
                    bot.setState(
                            BotState.IDLE
                    );
        }
    }

    // =========================================================
    // BASIC ACTIONS
    // =========================================================

    private void idle(Bot bot) {

        bot.setCurrentTask(
                "Idle"
        );

        /*
         * Idle bots eventually start exploring.
         */
        if (randomChance(30)) {

            bot.setState(
                    BotState.EXPLORING
            );
        }
    }

    private void explore(Bot bot) {

        bot.setCurrentTask(
                "Exploring the world"
        );

        bot.remember(
                "last_ai_action",
                "explore"
        );
    }

    private void travel(Bot bot) {

        bot.setCurrentTask(
                "Travelling to destination"
        );

        bot.remember(
                "last_ai_action",
                "travel"
        );
    }

    private void searchResource(Bot bot) {

        bot.setCurrentTask(
                "Searching for resources"
        );

        bot.remember(
                "last_ai_action",
                "search_resource"
        );
    }

    // =========================================================
    // GRINDING
    // =========================================================

    private void mine(Bot bot) {
        grinderController.tick(bot);
        bot.remember("last_ai_action", "mine");
    }

    private void farm(Bot bot) {
        grinderController.tick(bot);
        bot.setCurrentTask("Farming crops");
        bot.remember("last_ai_action", "farm");
    }

    private void bambooFarm(Bot bot) {
        bambooFarmController.tick(bot);
        bot.remember("resource", "BAMBOO");
        bot.remember("sell_method", "/sellgui");
        bot.remember("forbidden_command", "/sell");
        bot.remember("last_ai_action", "bamboo_farming");
    }

    // =========================================================
    // COMBAT
    // =========================================================

    private void pvp(Bot bot) {
        pvpController.tick(bot);
        bot.remember("last_ai_action", "pvp");
    }

    private void mobCombat(Bot bot) {
        pvpController.getCombatManager().tickCombat(bot);
        bot.setCurrentTask("Fighting hostile mobs");
        bot.remember("last_ai_action", "mob_combat");
    }

    private void collectLoot(Bot bot) {

        bot.setCurrentTask(
                "Collecting nearby loot"
        );

        bot.remember(
                "last_ai_action",
                "collect_loot"
        );
    }

    // =========================================================
    // INVENTORY
    // =========================================================

    private void manageInventory(Bot bot) {
        inventoryManager.remember(bot);
        bot.setCurrentTask("Managing inventory");
        bot.remember("last_ai_action", "inventory");
    }

    private void returnHome(Bot bot) {

        bot.setCurrentTask(
                "Returning to base"
        );

        bot.remember(
                "last_ai_action",
                "return_home"
        );
    }

    private void atBase(Bot bot) {

        bot.setCurrentTask(
                "Working at base"
        );

        bot.remember(
                "last_ai_action",
                "base"
        );
    }
        // =========================================================
    // BUILDING
    // =========================================================

    private void build(Bot bot) {
        if (!bot.getProfile().canBuild()) { bot.setState(BotState.EXPLORING); return; }
        if (bot.getBaseLocation() == null) bot.setBaseLocation(bot.getLocation());
        buildManager.buildBase(bot);
        bot.setCurrentTask("Building base");
        bot.remember("last_ai_action", "building");
    }

    private void repair(Bot bot) {

        bot.setCurrentTask(
                "Repairing equipment"
        );

        bot.remember(
                "last_ai_action",
                "repair"
        );
    }

    private void storeItems(Bot bot) {

        bot.setCurrentTask(
                "Storing items"
        );

        bot.remember(
                "last_ai_action",
                "store_items"
        );
    }

    // =========================================================
    // ECONOMY
    // =========================================================

    private void sell(Bot bot) {

        /*
         * Only MONEY bots should use the bamboo
         * selling workflow.
         */
        if (!bot.getRole().isMoney()) {

            bot.setState(
                    BotState.MANAGING_INVENTORY
            );

            return;
        }

        bot.setCurrentTask(
                "Selling bamboo through /sellgui"
        );

        /*
         * IMPORTANT:
         *
         * /sellgui = allowed
         * /sell    = forbidden
         */
        bot.remember(
                "last_command",
                "/sellgui"
        );
        bambooFarmController.sellWithSellGui(bot);

        bot.remember(
                "sell_method",
                "/sellgui"
        );

        bot.remember(
                "blocked_command",
                "/sell"
        );

        bot.remember(
                "last_ai_action",
                "sell_bamboo"
        );
    }

    private void checkBalance(Bot bot) {

        bot.setCurrentTask(
                "Checking balance"
        );

        bot.remember(
                "last_command",
                "/bal"
        );

        bot.remember(
                "last_ai_action",
                "balance_check"
        );
    }

    private void useCommand(Bot bot) {

        bot.setCurrentTask(
                "Using allowed server command"
        );

        bot.remember(
                "last_ai_action",
                "command"
        );
    }

    // =========================================================
    // SOCIAL AI
    // =========================================================

    private void talk(Bot bot) {

        if (!bot.getProfile().canChat()) {
            return;
        }

        bot.setCurrentTask(
                "Talking to players"
        );

        bot.remember(
                "last_ai_action",
                "talk"
        );
    }

    private void botConversation(Bot bot) {

        if (!bot.getProfile().canChat()) {
            return;
        }

        bot.setCurrentTask(
                "Talking with another bot"
        );

        bot.remember(
                "last_ai_action",
                "bot_conversation"
        );
    }

    private void followPlayer(Bot bot) {

        Player player =
                botManager.findNearestPlayer(
                        bot,
                        20.0
                );

        if (player == null) {

            bot.setState(
                    BotState.EXPLORING
            );

            return;
        }

        bot.setFollowingId(
                player.getUniqueId()
        );

        bot.setCurrentTask(
                "Following player "
                        + player.getName()
        );

        bot.remember(
                "following_player",
                player.getName()
        );
    }

    private void followBot(Bot bot) {

        Bot target =
                botManager.getRandomBot();

        if (target == null
                || target == bot
                || !target.isSpawned()) {

            return;
        }

        bot.setFollowingId(
                target.getId()
        );

        bot.setCurrentTask(
                "Following another bot"
        );

        bot.remember(
                "following_bot",
                target.getName()
        );
    }

    // =========================================================
    // DEFENSE
    // =========================================================

    private void defend(Bot bot) {

        bot.setCurrentTask(
                "Defending base"
        );

        bot.remember(
                "last_ai_action",
                "defend"
        );
    }

    // =========================================================
    // OBSERVATION
    // =========================================================

    private void observe(Bot bot) {

        bot.setCurrentTask(
                "Observing surroundings"
        );

        bot.remember(
                "last_ai_action",
                "observe"
        );
    }

    // =========================================================
    // MYSTERIOUS ACTIVITY
    // =========================================================

    private void mysteriousActivity(
            Bot bot
    ) {

        /*
         * UNKNOWN's real objective is intentionally
         * hidden from normal bot/player behaviour.
         */
        bot.setCurrentTask(
                "Unknown activity"
        );

        bot.remember(
                "mysterious_action",
                System.currentTimeMillis()
        );

        bot.remember(
                "objective_hidden",
                true
        );
    }

    // =========================================================
    // BUSY CHECK
    // =========================================================

    private boolean isBusy(Bot bot) {

        if (bot == null) {
            return false;
        }

        BotState state =
                bot.getState();

        if (state == null) {
            return false;
        }

        return switch (state) {

            case PVP_COMBAT,
                 MOB_COMBAT,
                 MINING,
                 FARMING,
                 BAMBOO_FARMING,
                 BUILDING,
                 SELLING,
                 USING_COMMAND,
                 TALKING,
                 BOT_CONVERSATION -> true;

            default -> false;
        };
    }

    // =========================================================
    // BUSY HANDLER
    // =========================================================

    private void handleBusyBot(
            Bot bot
    ) {

        /*
         * Don't randomly replace an active task.
         */
        if (bot.getCurrentTask() == null
                || bot.getCurrentTask().isBlank()) {

            bot.setCurrentTask(
                    "Continuing current task"
            );
        }

        /*
         * Refresh location while working.
         */
        if (bot.getEntity() != null
                && bot.getEntity().isValid()) {

            bot.setLocation(
                    bot.getEntity().getLocation()
            );
        }
    }

    // =========================================================
    // RANDOM UTILITIES
    // =========================================================

    private boolean randomChance(
            int percentage
    ) {

        if (percentage <= 0) {
            return false;
        }

        if (percentage >= 100) {
            return true;
        }

        return ThreadLocalRandom.current()
                .nextInt(100)
                < percentage;
    }

    private int random(
            int min,
            int max
    ) {

        if (max <= min) {
            return min;
        }

        return ThreadLocalRandom.current()
                .nextInt(
                        min,
                        max + 1
                );
    }

    // =========================================================
    // PUBLIC CONTROL
    // =========================================================

    public boolean isRunning() {
        return running;
    }

    public long getThinkInterval() {
        return thinkInterval;
    }

    public void setThinkInterval(
            long thinkInterval
    ) {

        if (thinkInterval < 1) {
            thinkInterval = 1;
        }

        this.thinkInterval =
                thinkInterval;

        /*
         * Restart scheduler so the new interval
         * takes effect immediately.
         */
        if (running) {

            shutdown();
            start();
        }
    }

    // =========================================================
    // GETTERS
    // =========================================================

    public FlameBotAI getPlugin() {
        return plugin;
    }

    public BotManager getBotManager() {
        return botManager;
    }

    // =========================================================
    // END OF AI CONTROLLER
    // =========================================================
}