package com.flamemc.flamebot;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/** Context-aware lightweight conversation state. */
public final class ConversationManager {
    private final FlameBotAI plugin;
    public ConversationManager(FlameBotAI plugin){this.plugin=plugin;}
    public void reply(Bot bot, Player player, String text){if(bot==null||player==null||text==null)return;bot.setLastMessage(text);bot.markChat();player.sendMessage("<"+bot.getName()+"> "+text);}
    public void broadcast(Bot bot,String text){if(bot==null||text==null)return;bot.setLastMessage(text);bot.markChat();Bukkit.broadcastMessage("<"+bot.getName()+"> "+text);}
    public FlameBotAI getPlugin(){return plugin;}
}
