
## Player NPC backend

FlameBotAI now uses Citizens PLAYER NPCs only. It does not use ArmorStands as a fallback.

Install a Citizens build compatible with the Minecraft/Paper version of the server. Each bot is created as `EntityType.PLAYER`, receives its Mojang skin by bot name, can appear in the player/tab list, and is exposed through Bukkit as a Player-type entity.

Important: a Citizens PLAYER NPC is not an authenticated network connection. Minecraft does not allow a server plugin to create a second genuine client connection from inside the server. If by “real player” you mean a player-looking, Player-type entity with skin/tab/movement/interactions, this is the supported approach.
